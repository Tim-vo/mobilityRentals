export const environment = {
  production: true,
  api_base: 'http://apigateway.dev.mobilityrental.kn01.fhict.nl',

  settings: {
    minimalpasswordlength: 6
  }
};
