import { TestBed } from '@angular/core/testing';

import { AccessDeniedInterceptor } from './access-denied.interceptor';

describe('AccessDeniedInterceptor', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      AccessDeniedInterceptor
      ]
  }));

  it('should be created', () => {
    const interceptor: AccessDeniedInterceptor = TestBed.inject(AccessDeniedInterceptor);
    expect(interceptor).toBeTruthy();
  });
});
