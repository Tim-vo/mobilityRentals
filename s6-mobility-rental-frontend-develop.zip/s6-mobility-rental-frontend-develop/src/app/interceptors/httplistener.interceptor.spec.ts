import { TestBed } from '@angular/core/testing';

import { HTTPListenerInterceptor } from './httplistener.interceptor';

describe('HTTPListenerInterceptor', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      HTTPListenerInterceptor
      ]
  }));

  it('should be created', () => {
    const interceptor: HTTPListenerInterceptor = TestBed.inject(HTTPListenerInterceptor);
    expect(interceptor).toBeTruthy();
  });
});
