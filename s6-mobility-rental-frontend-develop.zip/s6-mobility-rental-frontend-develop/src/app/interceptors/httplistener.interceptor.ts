import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor, HttpErrorResponse
} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {catchError, finalize, map} from "rxjs/operators";

@Injectable()
export class HTTPListener implements HttpInterceptor {

  constructor() {
  }

  errorHandler(error: HttpErrorResponse) {
    return throwError(error.message || 'server error.');
  }

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {

    const languageRequest = req.clone({ setHeaders: { 'Accept-Language': localStorage.getItem('Language') } });
    return next.handle(languageRequest).pipe(
      map(event => {
        return event;
      }),
      catchError(this.errorHandler),
      finalize(() => {
      })
    );
  }
}
