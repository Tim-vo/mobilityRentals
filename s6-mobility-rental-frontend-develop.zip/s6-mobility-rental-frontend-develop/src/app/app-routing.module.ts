import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AccountComponent } from "./component/account/account.component";
import { AssetComponent } from "./component/asset/asset.component";
import { OrderComponent } from "./component/order/order.component";
import { LoginComponent } from "./component/login/login.component";
import { NotFoundComponent } from "./component/errors/not-found/not-found.component";
import { RegisterComponent } from "./component/register/register.component";
import { HomeComponent } from "./component/home/home.component";
import { HttpClientModule } from "@angular/common/http";
import { InternalServerComponent } from "./component/errors/internal-server/internal-server.component";
import { AssetsComponent } from "./component/assets/assets.component";
import { DashboardComponent } from "./component/dashboard/dashboard.component";
import { UnauthorizedComponent } from './component/unauthorized/unauthorized.component';
import { OrderAccountComponent } from './component/order/order-account/order-account.component';
import { AccountDetailsComponent } from './component/account-details/account-details.component';
import { UserOrdersComponent } from './component/user-orders/user-orders.component';
import { AboutComponent } from './component/about/about.component';
import { OrderDetailsComponent } from './component/order-details/order-details.component';
import {QuotationRequestComponent} from "./component/dashboard/quotation-request/quotation-request.component";
import {AssignmentComponent} from "./component/dashboard/assignment/assignment.component";

const routes: Routes = [
  { path: "", component: HomeComponent },

  { path: "account", component: AccountComponent },
  { path: "account/orders", component: UserOrdersComponent },
  { path: "account/orders/:id", component: OrderDetailsComponent },
  { path: "account/details", component: AccountDetailsComponent },

  { path: "about", component: AboutComponent },

  { path: "assets", component: AssetsComponent },
  { path: "asset", component: AssetComponent },
  { path: "order/:assetId", component: OrderComponent },

  { path: "login", component: LoginComponent },
  { path: "register", component: RegisterComponent },

  { path: "assets", component: AssetsComponent },
  { path: "asset/:id", component: AssetComponent },

  { path: "dashboard", component: DashboardComponent },
  { path: "request", component: QuotationRequestComponent },
  { path: "task/:assignmentId", component: AssignmentComponent},

  { path: "401", component: UnauthorizedComponent },
  { path: "404", component: NotFoundComponent },
  { path: "500", component: InternalServerComponent },

  { path: "**", redirectTo: "/404" },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule, HttpClientModule],
})
export class AppRoutingModule {}
