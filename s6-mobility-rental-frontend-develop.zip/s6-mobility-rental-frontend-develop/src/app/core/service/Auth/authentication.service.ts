import { Injectable } from "@angular/core";
import { HttpHeaders, HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { environment } from "src/environments/environment";
import { Account } from "src/app/model/Account";
import { JwtHelperService } from "@auth0/angular-jwt";
import { RoleName } from 'src/app/model/role-name.enum';

@Injectable({
  providedIn: "root",
})
export class AuthenticationService {
  jwtReader: JwtHelperService = new JwtHelperService();

  constructor(private http: HttpClient) {}

  public login(account): Observable<Account> {
    return this.http.post<Account>(
      environment.api_base + `/account-api/login`,
      account
    );
  }

  public register(account): Observable<Account> {
    return this.http.post<Account>(
      environment.api_base + `/account-api/register`,
      account
    );
  }

  isTokenExpired(token?: string): boolean {
    return false;
    if (!token) token = this.getToken();
    if (!token) return true;
  }

  public setToken(token: string) {
    localStorage.setItem("Token", token);
  }

  public clearToken() {
    localStorage.removeItem("Token");
  }

  public getToken() {
    return localStorage.getItem("Token");
  }

  public tokenExistsAndValid(): boolean {
    var token = this.getToken();
    if (token && !this.isTokenExpired(token)) {
      return true;
    }
    return false;
  }
  
  getHeaders(): HttpHeaders {
    return new HttpHeaders({
      "Content-Type": "application/json",
      Authorization: "bearer " + this.getToken(),
    });
  }

  public getUserId() {
    return this.jwtReader.decodeToken(this.getToken())[
      "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"
    ];
  }
}
