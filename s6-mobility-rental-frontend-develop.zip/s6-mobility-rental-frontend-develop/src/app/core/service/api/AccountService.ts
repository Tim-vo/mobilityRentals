import { Injectable } from "@angular/core";
import { environment } from "../../../../environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { Account } from "../../../model/Account";
import { AuthenticationService } from "../Auth/authentication.service";

@Injectable()
export class AccountService {
  private API_BASE = environment.api_base;
  constructor(
    private http: HttpClient,
    private authService: AuthenticationService
  ) {}

  //register and login happen in the auth service

  public getAccount(): Observable<Account> {
    return this.http.get<Account>(environment.api_base + `/account-api/`, {
      headers: this.authService.getHeaders(),
    });
  }
}
