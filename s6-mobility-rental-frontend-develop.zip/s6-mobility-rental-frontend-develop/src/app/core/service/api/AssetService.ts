import { environment } from "../../../../environments/environment";
import { Observable } from "rxjs";
import { Asset } from "../../../model/Asset";
import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { catchError } from "rxjs/operators";
import { throwError } from "rxjs";
import { Brand } from "../../../model/Brand";

@Injectable()
export class AssetService {
  private API_BASE = environment.api_base;

  constructor(private http: HttpClient) {}

  errorHandler(error: HttpErrorResponse) {
    return throwError(error.message || "server error.");
  }

  public getAsset(id: number): Observable<Asset> {
    return this.http
      .get<Asset>(this.API_BASE + `/asset-api/${id}`)
      .pipe(catchError(this.errorHandler));
  }

  public getAssetPage(
    pageNumber: number,
    amount: number,
    typeId: number,
    brands: string,
    minPrice: number,
    maxPrice: number,
    ascending: boolean
  ): Observable<Array<Asset>> {
    let body = {
      pageNumber: pageNumber,

      typeId: typeId,
      brands: brands,
      minPrice: minPrice,
      maxPrice: maxPrice,
      priceAscending: ascending,
      amount: amount,
    };

    return this.http.post<any>(this.API_BASE + "/asset-api/page", body);
  }

  public searchAsset(): Observable<Array<Asset>> {
    return this.http.get<Array<Asset>>(this.API_BASE + "/asset-api/search");
  }

  public getAssetsBrands(
    collectAssets: boolean,
    type: number
  ): Observable<Array<Brand>> {
    return this.http.get<Array<Brand>>(
      this.API_BASE +
        `/asset-api/brands?getNumberOfAssets=${collectAssets}&typeId=${type}`
    );
  }
}
