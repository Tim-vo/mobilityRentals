import { environment } from "../../../../environments/environment";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { Asset } from "../../../model/Asset";
import { catchError } from "rxjs/operators";
import { Task } from "../../../model/Task";
import { Injectable } from "@angular/core";
import { AuthenticationService } from "../Auth/authentication.service";
import { SubAssignment } from "../../../model/SubAssignment";
import { Quotation } from "../../../model/Quotation";
import { Dealer } from "src/app/model/dealer";

@Injectable()
export class TaskService {
  private API_BASE = environment.api_base;

  constructor(private http: HttpClient, private auth: AuthenticationService) {}

  errorHandler(error: HttpErrorResponse) {
    return throwError(error.message || "server error.");
  }

  public getTask(id: string): Observable<Task> {
    return this.http
      .get<Task>(this.API_BASE + `/assignment-api/${id}`, {
        headers: this.auth.getHeaders(),
      })
      .pipe(catchError(this.errorHandler));
  }

  public getUserTasks(): Observable<Task[]> {
    return this.http
      .get<Array<Task>>(this.API_BASE + "/assignment-api/user", {
        headers: this.auth.getHeaders(),
      })
      .pipe(catchError(this.errorHandler));
  }

  public getSubAssignment(): Observable<SubAssignment[]> {
    return this.http
      .get<Array<SubAssignment>>(this.API_BASE + "/subassignment-api/user", {
        headers: this.auth.getHeaders(),
      })
      .pipe(catchError(this.errorHandler));
  }

  public postResponse(
    price: number,
    subId: string,
    accepted: boolean
  ): Observable<SubAssignment> {
    let body = {
      accepted: accepted,
      price: price,
    };
    return this.http
      .put<SubAssignment>(
        this.API_BASE + `/subassignment-api/${subId}/accept`,
        body,
        {
          headers: this.auth.getHeaders(),
        }
      )
      .pipe(catchError(this.errorHandler));
  }

  public selectDealer(assignmentId: Number, dealer: Dealer): Observable<Task> {
    return this.http
      .post<Task>(
        this.API_BASE + "/assignment-api/" + assignmentId + "/select-dealer",
        dealer,
        { headers: this.auth.getHeaders() }
      )
      .pipe(catchError(this.errorHandler));
  }

  public notifyArrival(task: Task): Observable<Task> {
    return this.http
      .post<Task>(this.API_BASE + "/assignment-api/notify-arrival", task, {
        headers: this.auth.getHeaders(),
      })
      .pipe(catchError(this.errorHandler));
  }

  public requestRegistration(task: Task): Observable<Task> {
    return this.http
      .post<Task>(
        this.API_BASE + "/assignment-api/request-registration",
        task,
        { headers: this.auth.getHeaders() }
      )
      .pipe(catchError(this.errorHandler));
  }

  public grantRregistrationPermission(task: Task): Observable<Task> {
    return this.http
      .post<Task>(this.API_BASE + "/assignment-api/handle-request", task, {
        headers: this.auth.getHeaders(),
      })
      .pipe(catchError(this.errorHandler));
  }

  public completeRegistration(task: Task): Observable<Task> {
    return this.http
      .put<Task>(
        this.API_BASE + "/assignment-api/registration-complete",
        task,
        { headers: this.auth.getHeaders() }
      )
      .pipe(catchError(this.errorHandler));
  }
}
