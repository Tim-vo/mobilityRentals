import { environment } from "../../../../environments/environment";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Order } from "../../../model/Order";
import { Injectable } from "@angular/core";
import { AuthenticationService } from "../Auth/authentication.service";
import { OrderAsset } from "../../../model/OrderAsset";

@Injectable()
export class OrderService {
  private API_BASE = environment.api_base;

  constructor(
    private http: HttpClient,
    private authService: AuthenticationService
  ) { }

  public getAccountOrders(): Observable<Array<Order>> {
    return this.http.get<Array<Order>>(this.API_BASE + "/order-api/account", {
      headers: this.authService.getHeaders(),
    });
  }

  public getOrder(id: string): Observable<Order> {
    return this.http.get<Order>(this.API_BASE + `/order-api/${id}`, {
      headers: this.authService.getHeaders(),
    });
  }

  public addOrder(orderAsset: OrderAsset): Observable<Order> {
    return this.http.post<Order>(this.API_BASE + "/order-api/", orderAsset, {
      headers: this.authService.getHeaders(),
    });
  }
}
