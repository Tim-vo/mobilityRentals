import { Injectable } from '@angular/core';
import { RoleName } from 'src/app/model/role-name.enum';
import { AuthenticationService } from './Auth/authentication.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Role } from 'src/app/model/role';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RoleService {

  constructor(
    private http: HttpClient,
    private authService: AuthenticationService
  ) { }

  public GetAllAccountRoles(): Observable<Role[]> {
    return this.http.get<Role[]>(environment.api_base + `/roles-api/current/all`, {
      headers: this.authService.getHeaders(),
    });
  }

  public HasRole(targetRole: RoleName): boolean {
    let jwt = this.authService.getToken();

    let jwtData = jwt.split('.')[1]
    let decodedJwtJsonData = window.atob(jwtData)
    let decodedJwtData = JSON.parse(decodedJwtJsonData)

    var roles = decodedJwtData["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"]
    var result: boolean = false;
    if (roles != null) {
      if (typeof roles === 'string') {
        result = (roles == targetRole)
      }
      else {
        roles.forEach(role => {
          if (role == targetRole) {
            result = true;
          }
        });
      }
    }
    console.log("Has access? " + result);

    return result;
  }
}
