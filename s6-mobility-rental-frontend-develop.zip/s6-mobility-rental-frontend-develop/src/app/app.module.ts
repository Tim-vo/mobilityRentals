import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AccountComponent } from './component/account/account.component';
import { AssetComponent } from './component/asset/asset.component';
import { OrderComponent } from './component/order/order.component';
import { LoginComponent } from './component/login/login.component';
import { NotFoundComponent } from './component/errors/not-found/not-found.component';
import { RegisterComponent } from './component/register/register.component';
import { HomeComponent } from './component/home/home.component';
import { LoadIconComponent } from './component/load-icon/load-icon.component';
import { InternalServerComponent } from './component/errors/internal-server/internal-server.component';
import { AssetService } from './core/service/api/AssetService';
import { AccountService } from './core/service/api/AccountService';
import { OrderService } from './core/service/api/OrderService';
import { AssetsComponent } from './component/assets/assets.component';
import { HeaderComponent } from './component/header/header.component';
import { FooterComponent } from './component/footer/footer.component';
import {TranslateLoader, TranslateModule} from '@ngx-translate/core';
import {HTTP_INTERCEPTORS, HttpClient} from '@angular/common/http';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import { OrderPreviewComponent } from './component/order/order-preview/order-preview.component';
import { AssetSpecificationsComponent } from './component/order/asset-specifications/asset-specifications.component';
import { AssetAccessoriesComponent } from './component/order/asset-accessories/asset-accessories.component';
import { PersonalInformationComponent } from './component/order/personal-information/personal-information.component';
import { OrderAccountComponent } from './component/order/order-account/order-account.component';
import { UnauthorizedComponent } from './component/unauthorized/unauthorized.component';
import { DashboardComponent } from './component/dashboard/dashboard.component';
import { TaskListComponent } from './component/dashboard/task-list/task-list.component';
import {HTTPListener} from "./interceptors/httplistener.interceptor";
import { UserOrdersComponent } from './component/user-orders/user-orders.component';
import { AccountDetailsComponent } from './component/account-details/account-details.component';
import { AboutComponent } from './component/about/about.component';
import { OrderDetailsComponent } from './component/order-details/order-details.component';
import {TaskService} from "./core/service/api/TaskService";
import { QuotationRequestComponent } from './component/dashboard/quotation-request/quotation-request.component';
import { AssignmentComponent } from './component/dashboard/assignment/assignment.component';
import { QuotationResultsComponent } from './component/dashboard/assignment/quotation-results/quotation-results.component';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '-lang.json');
}

@NgModule({
  declarations: [
    AppComponent,
    AccountComponent,
    AssetComponent,
    OrderComponent,
    LoginComponent,
    NotFoundComponent,
    RegisterComponent,
    HomeComponent,
    LoadIconComponent,
    InternalServerComponent,
    AssetsComponent,
    HeaderComponent,
    FooterComponent,
    OrderPreviewComponent,
    AssetSpecificationsComponent,
    AssetAccessoriesComponent,
    PersonalInformationComponent,
    OrderAccountComponent,
    UnauthorizedComponent,
    DashboardComponent,
    TaskListComponent,
    UserOrdersComponent,
    AccountDetailsComponent,
    AboutComponent,
    OrderDetailsComponent,
    QuotationRequestComponent,
    AssignmentComponent,
    QuotationResultsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [
    AssetService,
    AccountService,
    OrderService,
    TaskService,
    { provide: HTTP_INTERCEPTORS, useClass: HTTPListener, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
