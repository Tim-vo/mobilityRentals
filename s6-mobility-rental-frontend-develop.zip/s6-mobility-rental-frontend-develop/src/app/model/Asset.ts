import { AssetType } from "./AssetType";
import { Brand } from "./Brand";
import { Specification } from "./specification";
import { Accessory } from "./accessory";

export class Asset {
  id: string;
  name: string;
  type: AssetType;
  serialNumber: string;
  photoUrl: string;
  price: number;
  description: string;
  available: boolean;
  brand: Brand;
  specifications: Specification[];
  accessories: Accessory[];
  partnerAssetId: number;
  partnerReferralLink: string;
}
