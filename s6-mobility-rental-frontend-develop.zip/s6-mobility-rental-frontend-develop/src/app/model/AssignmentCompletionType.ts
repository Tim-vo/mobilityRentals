export enum AssignmentCompletionType {
  ALL,
  ONE,
  NONE
}
