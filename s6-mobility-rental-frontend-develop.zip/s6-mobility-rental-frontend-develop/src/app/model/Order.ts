import { Asset } from "./Asset";
import { OrderState } from "./OrderState";
import { PersonalInformation } from "./personal-information";

export class Order {
  id: string;
  assetId: string;
  orderDate: Date;
  startDate: Date;
  endDate: Date;
  state: OrderState;
  deliver: boolean;
  accessories: string;
  personalInformation: PersonalInformation;
}
