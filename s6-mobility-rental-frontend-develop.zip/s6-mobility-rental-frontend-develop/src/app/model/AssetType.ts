export enum AssetType {
  PassengerVehicle = 0,
  Bicycle = 1,
  MoterBike = 2,
  Boat = 3,
  Jetski = 4,
  Bus = 5,
  Tram = 6,
  Train = 7,
  Plane = 8,
  SmallTruck = 9,
  BigTruck = 10
}
