import {Brand} from "./Brand";
import {AssetType} from "./AssetType";

export class Filter {
  minPrice: number;
  MaxPrice: number;
  Brand: Brand;
  Type: AssetType;
}
