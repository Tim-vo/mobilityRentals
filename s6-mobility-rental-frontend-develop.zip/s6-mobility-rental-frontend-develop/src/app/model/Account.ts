export class Account {
  id: string;
  email:	string;
  password:	string;
  firstName: string;
  lastName: string;
  token: string;
  creationDate: Date;
}
