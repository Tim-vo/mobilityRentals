export enum AssignmentType {
  CostumerOrdered,
    AssetRequestedFromDealer,
    AssetReceivedByDealer,
    AssetReadyByDealer,
    RegistrationRequested,
    RegistrationProcessStarted,
    RegistrationCompleted,
}
