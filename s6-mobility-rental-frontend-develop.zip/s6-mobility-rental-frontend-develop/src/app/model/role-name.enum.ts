
//A way so we can easily edit the role names if changed in the DB
export enum RoleName {
    Admin = "Administrator",
    Employee = "Employee",
    RoleAdmin = "RoleAdministrator",
    PrivilegedUser = "PrivilegedUser"
}