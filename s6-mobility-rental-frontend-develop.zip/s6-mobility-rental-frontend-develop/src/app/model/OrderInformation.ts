export class OrderInformation {
  id: string;
  orderNumber: string;
  orderDate: Date;
  startDate: Date;
  endDate: Date;
  assetName: string;
  serialNumber: string;
  accessories: string;
}
