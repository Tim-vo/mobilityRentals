export enum OrderState {
  notProcessed = 0,
  processed = 1
}
