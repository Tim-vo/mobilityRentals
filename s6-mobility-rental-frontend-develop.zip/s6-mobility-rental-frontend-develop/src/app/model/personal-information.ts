export class PersonalInformation {
  name: string;
  email: string;
  city: string;
  address: string;
  zipcode: string;
}
