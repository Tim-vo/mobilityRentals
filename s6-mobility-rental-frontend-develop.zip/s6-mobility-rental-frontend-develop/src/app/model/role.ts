export class Role {
    name: string;
    description: string;
}
