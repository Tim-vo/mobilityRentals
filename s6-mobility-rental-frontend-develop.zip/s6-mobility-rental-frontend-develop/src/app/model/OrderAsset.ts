import {Order} from "./Order";
import {Asset} from "./Asset";

export class OrderAsset {

  public constructor(order: Order, asset: Asset) {
    this.GetOrder = order;
    this.GetAsset = asset;
  }

  GetOrder: Order;
  GetAsset: Asset;
}
