export enum AssignmentState {
  Open = 0,
  Closed = 1,
  InProgress = 2,
  Pending = 3,
  Blocked = 4,
  Duplicate = 5
}
