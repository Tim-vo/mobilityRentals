import DateTimeFormat = Intl.DateTimeFormat;
import { SubAssignment } from "./SubAssignment";
import { AssignmentState } from "./AssignmentState";
import { AssignmentType } from "./AssignmentType";
import { AssignmentCompletionType } from "./AssignmentCompletionType";
import { OrderInformation } from "./OrderInformation";

export class Task {
  id: number;
  state: AssignmentState;
  type: AssignmentType;
  completionType: AssignmentCompletionType;
  name: string;
  assignedAccount: string;
  reportingAccount: string;
  subAssignments: Array<SubAssignment>;
  orderNumber: string;
  created: Date;
  lastUpdate: Date;
  numberplate: string;
  permissionGranted: boolean;
  hasCompleted: boolean;
  orderInformationSet: OrderInformation;
}
