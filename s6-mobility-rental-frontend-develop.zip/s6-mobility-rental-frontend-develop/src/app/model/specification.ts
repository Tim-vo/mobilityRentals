export class Specification {
  id: string;
  name: string;
  value: string;
}
