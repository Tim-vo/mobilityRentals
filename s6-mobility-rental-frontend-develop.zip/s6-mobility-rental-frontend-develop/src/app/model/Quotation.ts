export class Quotation {
  accepted: Boolean;
  price: number;
}
