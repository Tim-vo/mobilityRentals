export class Dealer {
  id: string;
}
