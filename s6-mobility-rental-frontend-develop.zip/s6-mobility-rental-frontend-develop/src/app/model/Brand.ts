export class Brand {
  id: number;
  name: string;
  assetCount: number;
}
