import DateTimeFormat = Intl.DateTimeFormat;
import { AssignmentState } from "./AssignmentState";
import { OrderInformation } from "./OrderInformation";

export class SubAssignment {
  id: string;
  name: string;
  description: string;
  assignedAccount: string;
  count: string;
  state: AssignmentState;
  accepted: boolean;
  price: number;
  created: Date;
  lastUpdate: Date;
  orderInformationSet: OrderInformation;
}
