export class Accessory {
  id: string;
  name: string;
}
