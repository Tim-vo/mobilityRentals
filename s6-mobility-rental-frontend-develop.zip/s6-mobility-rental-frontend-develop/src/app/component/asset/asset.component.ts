import { Component, OnInit, Input } from '@angular/core';
import { Asset } from 'src/app/model/Asset';
import { ActivatedRoute, Router } from '@angular/router';
import { AssetService } from 'src/app/core/service/api/AssetService';
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: 'app-asset',
  templateUrl: './asset.component.html',
  styleUrls: ['./asset.component.scss']
})
export class AssetComponent implements OnInit {
  @Input()
  currentId: string;
  asset: Asset;

  constructor(private activatedRoute: ActivatedRoute,
    private assetService: AssetService,
    private currentRouter: Router) { }

  ngOnInit(): void {
    if (!this.currentId) {
      this.currentId = this.activatedRoute.snapshot.paramMap.get('id');
    }
    this.assetService.getAsset(parseInt(this.currentId)).subscribe(data => {
      this.asset = data;
    },
      error => {
        console.error(error);
        this.currentRouter.navigate(["/500"]);
      });
  }

}
