import { Component, OnInit } from '@angular/core';
import { OrderService } from 'src/app/core/service/api/OrderService';
import { Order } from 'src/app/model/Order';

@Component({
  selector: 'app-user-orders',
  templateUrl: './user-orders.component.html',
  styleUrls: ['./user-orders.component.css']
})
export class UserOrdersComponent implements OnInit {
  orders: Order[];

  constructor(private orderService: OrderService) { }

  ngOnInit(): void {
    this.orderService.getAccountOrders().subscribe(
      (data) => {
        this.orders = data;

        this.orders = this.orders.sort(function (a, b) {
          return new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime();
        });
      });
  }

}
