import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { AuthenticationService } from 'src/app/core/service/Auth/authentication.service';
import { Router } from '@angular/router';
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.scss"],
})
export class RegisterComponent implements OnInit {
  @Input() routeToDashboard: boolean = true;

  registerForm: FormGroup;
  submitted = false;
  errorText: string;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthenticationService,
    private router: Router) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      email: ["", [Validators.required, Validators.email]],
      password: [
        "",
        [
          Validators.required,
          Validators.minLength(environment.settings.minimalpasswordlength),
        ],
      ],
    });
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.registerForm.controls;
  }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      this.submitted = false;
      this.errorText = "Please fill all fields";
      return;
    }

    this.authService.register(this.registerForm.value).subscribe(
      (data) => {
        this.submitted = false;
        this.authService.setToken(data.token);
        if (this.routeToDashboard) this.RouteToDash();
      },
      (error) => {
        if (error.status == 401) {
          this.errorText = "Register has failed. Credentials were invalid";
        }
        else if (error.status == 500) {
          this.errorText = "The register attempt encountered an error";
        } else {
          this.errorText = "Registering currently isn't available.";
        }
        console.debug(error);
        this.submitted = false;
      }
    );
  }

  RouteToDash() {
    this.router.navigate(["./account"]);
  }
}
