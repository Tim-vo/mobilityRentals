import { Component, OnInit } from '@angular/core';
import { TranslateService } from "@ngx-translate/core";
import { AuthenticationService } from 'src/app/core/service/Auth/authentication.service';
import { Router } from '@angular/router';
import { RoleService } from 'src/app/core/service/role.service';
import { RoleName } from 'src/app/model/role-name.enum';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss']
})
export class AccountComponent implements OnInit {
  priviliged: boolean = false;

  constructor(private translate: TranslateService,
    private authService: AuthenticationService,
    private router: Router,
    private roleService: RoleService) {
    translate.setDefaultLang('en');
  }

  ngOnInit(): void {
    if (this.authService.tokenExistsAndValid()){
      console.log("Found a token");

      if (this.roleService.HasRole(RoleName.PrivilegedUser) || this.roleService.HasRole(RoleName.Admin)){
        this.priviliged = true;
      }
    }
    else{
      console.log("No token found");
      this.routeToLogin();
    }
  }

  private routeToLogin(){
    this.router.navigate(['./login']);
  }

}
