import { Component, OnInit } from '@angular/core';
import { AccountService } from 'src/app/core/service/api/AccountService';
import { Account } from 'src/app/model/Account';
import { AuthenticationService } from 'src/app/core/service/Auth/authentication.service';
import { RoleName } from 'src/app/model/role-name.enum';
import { RoleService } from 'src/app/core/service/role.service';
import { Role } from 'src/app/model/role';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {
  account: Account;
  roles: Role[];

  constructor(private accountService: AccountService,
    private roleService: RoleService) { }

  ngOnInit(): void {
    this.accountService.getAccount().subscribe(
      (data) => {
        this.account = data;
        if (this.roleService.HasRole(RoleName.PrivilegedUser) || this.roleService.HasRole(RoleName.Admin)) {
          this.displayRoles();
        }
      });
  }

  displayRoles() {
    this.roleService.GetAllAccountRoles().subscribe(
      (data) => {
        this.roles = data;
      });
  }
}
