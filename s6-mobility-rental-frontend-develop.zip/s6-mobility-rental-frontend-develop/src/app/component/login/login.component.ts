import { Component, Input, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { environment } from "src/environments/environment";
import { AuthenticationService } from "src/app/core/service/Auth/authentication.service";
import { Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"],
})
export class LoginComponent implements OnInit {
  @Input() routeToDashboard: boolean = true;

  loginForm: FormGroup;
  submitted = false;
  errorText: string;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthenticationService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ["", Validators.required],
      password: [
        "",
        [
          Validators.required,
          Validators.minLength(environment.settings.minimalpasswordlength),
        ],
      ],
    });

    if (this.authService.tokenExistsAndValid()) {
      console.log("Found a token");
      if (this.routeToDashboard) this.RouteToDash();
    } else {
      console.log("No token found");
    }
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls;
  }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      this.submitted = false;
      this.errorText = "Please fill all fields";
      return;
    }

    this.authService.login(this.loginForm.value).subscribe(
      (data) => {
        console.log(data);
        this.submitted = false;
        this.authService.setToken(data.token);
        if (this.routeToDashboard) this.RouteToDash();
      },
      (error) => {
        if (error.status == 401) {
          this.errorText = "Login failed. Wrong credentials.";
        } else {
          console.error(error);
          this.errorText = "Login currently isn't available.";
        }
        this.submitted = false;
      }
    );
  }

  RouteToDash() {
    this.router.navigate(["./account"]);
  }
}
