import { Component, Input, OnInit } from "@angular/core";
import { Asset } from "../../model/Asset";
import { AssetType } from "../../model/AssetType";
import { Brand } from "../../model/Brand";
import { ActivatedRoute, Router } from "@angular/router";
import { AssetService } from "../../core/service/api/AssetService";
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: "app-assets",
  templateUrl: "./assets.component.html",
  styleUrls: ["./assets.component.scss"],
})
export class AssetsComponent implements OnInit {
  public asset: Asset;
  public brand: Brand;
  public assetList: Array<Asset>;
  public brandList: Array<Brand>;
  @Input() public minPrice: number = 0;
  @Input() public maxPrice: number = 100000;
  public page: number = 1;
  public amount: number = 20;
  public typeId: number = -1;
  public brands: string = "";
  public ascending: boolean = true;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private assetService: AssetService
  ) {}

  ngOnInit(): void {
    this.getBrand();
    this.getAssets();
  }

  /*
  Return AssetType as string instead of number.
   */
  getAssetTypeAsString(type: AssetType) {
    return AssetType[type];
  }

  getBrand() {
    this.assetService
      .getAssetsBrands(true, 1)
      .subscribe((brands) => (this.brandList = brands));
  }

  getAssets() {
    this.assetService
      .getAssetPage(
        this.page,
        this.amount,
        this.typeId,
        this.brands,
        this.minPrice,
        this.maxPrice,
        this.ascending
      )
      .subscribe((assets) => (this.assetList = assets));
  }

  setPrice() {}
}
