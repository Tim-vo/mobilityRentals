import { Component, OnInit } from '@angular/core';
import { Order } from 'src/app/model/Order';
import { OrderService } from 'src/app/core/service/api/OrderService';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit {
  order: Order;

  constructor(private activatedRoute: ActivatedRoute,
    private orderService: OrderService,
    private currentRouter: Router) { }

  ngOnInit(): void {
    var id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id) {
      id = id as string;
      this.orderService.getOrder(id).subscribe(
        (data) => {
          if (data) { 
            this.order = data; 
          }
          else {
            this.currentRouter.navigate(["/404"]);
          }
        },
        (error) => {
          this.currentRouter.navigate(["/500"]);
        }
        );
    }
    else {
      this.currentRouter.navigate(["/404"]);
    }
  }

}
