import { Component, OnInit } from "@angular/core";
import { AuthenticationService } from "src/app/core/service/Auth/authentication.service";
import { Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.scss"],
})
export class HeaderComponent implements OnInit {
  constructor(
    private authService: AuthenticationService,
    private router: Router,
    private translate: TranslateService
  ) {
    router.events.subscribe((val) => { });
    if (localStorage.getItem("Language") === null) {
      translate.setDefaultLang("en-us");
      localStorage.setItem("Language", "en-us");
    } else {
      translate.setDefaultLang(localStorage.getItem("Language"));
    }
  }

  ngOnInit(): void { }

  checkState() {
    return this.authService.tokenExistsAndValid();
  }

  useLanguage(language: string) {
    this.translate.use(language);
    localStorage.setItem("Language", language);
  }

  Logout() {
    console.log("Attempt to logout");
    this.authService.clearToken();
    this.router.navigate(["./login"]);
  }
}
