import { Component, OnInit, Input, ViewChild } from "@angular/core";
import { PersonalInformation } from "src/app/model/personal-information";
import { Order } from "src/app/model/Order";

@Component({
  selector: "app-personal-information",
  templateUrl: "./personal-information.component.html",
  styleUrls: ["./personal-information.component.scss"],
})
export class PersonalInformationComponent implements OnInit {
  @Input() orderStep: number;
  @Input() order: Order;

  constructor() {}

  ngOnInit(): void {}

  public isFormValid(): boolean {
    if (this.order.personalInformation.name.length == 0) return false;

    return true;
  }
}
