import { Component, OnInit, Input } from "@angular/core";
import { Accessory } from "src/app/model/accessory";
import { Asset } from "src/app/model/Asset";

@Component({
  selector: "app-asset-accessories",
  templateUrl: "./asset-accessories.component.html",
  styleUrls: ["./asset-accessories.component.scss"]
})
export class AssetAccessoriesComponent implements OnInit {
  @Input() asset: Asset;
  @Input() selectedAccessories: Accessory[];

  constructor() {}

  ngOnInit(): void {}

  toggleAccessory(accessory: Accessory) {
    const index: number = this.selectedAccessories.indexOf(accessory);

    if (index >= 0) this.selectedAccessories.splice(index, 1);
    else this.selectedAccessories.push(accessory);
  }
}
