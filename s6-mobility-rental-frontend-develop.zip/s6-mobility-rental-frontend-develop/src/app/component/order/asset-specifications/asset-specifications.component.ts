import { Component, OnInit, Input } from "@angular/core";
import { Asset } from "src/app/model/Asset";

@Component({
  selector: "app-asset-specifications",
  templateUrl: "./asset-specifications.component.html",
  styleUrls: ["./asset-specifications.component.scss"]
})
export class AssetSpecificationsComponent implements OnInit {
  @Input() asset: Asset;

  constructor() {}

  ngOnInit(): void {}
}
