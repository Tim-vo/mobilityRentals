import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetSpecificationsComponent } from './asset-specifications.component';

describe('AssetSpecificationsComponent', () => {
  let component: AssetSpecificationsComponent;
  let fixture: ComponentFixture<AssetSpecificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetSpecificationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetSpecificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
