import { Component, OnInit, Input } from "@angular/core";
import { Asset } from "src/app/model/Asset";
import { Accessory } from "src/app/model/accessory";

@Component({
  selector: "app-order-preview",
  templateUrl: "./order-preview.component.html",
  styleUrls: ["./order-preview.component.scss"]
})
export class OrderPreviewComponent implements OnInit {
  @Input() asset: Asset;
  @Input() selectedAccessories: Accessory[];

  constructor() {}

  ngOnInit(): void {}
}
