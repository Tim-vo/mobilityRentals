import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-order-account",
  templateUrl: "./order-account.component.html",
  styleUrls: ["./order-account.component.scss"],
})
export class OrderAccountComponent implements OnInit {
  selectedAccountOption: number = 0;

  constructor() {}

  ngOnInit(): void {}

  public SelectAccountOption(option: number) {
    this.selectedAccountOption = option;
  }
}
