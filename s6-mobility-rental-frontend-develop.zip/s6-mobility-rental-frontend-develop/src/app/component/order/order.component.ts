import { Component, OnInit, ViewChild } from "@angular/core";
import { Asset } from "src/app/model/Asset";
import { ActivatedRoute, Router } from "@angular/router";
import { OrderService } from "src/app/core/service/api/OrderService";
import { AssetService } from "src/app/core/service/api/AssetService";
import { Order } from "src/app/model/Order";
import { Accessory } from "src/app/model/accessory";
import { PersonalInformation } from "src/app/model/personal-information";
import { AuthenticationService } from "src/app/core/service/Auth/authentication.service";
import { OrderAsset } from "../../model/OrderAsset";

@Component({
  selector: "app-order",
  templateUrl: "./order.component.html",
  styleUrls: ["./order.component.scss"],
})
export class OrderComponent implements OnInit {
  @ViewChild("personalInformationComponent") personalInformationComponent;

  currentId: string;
  asset: Asset;
  selectedAccessories: Accessory[] = [];
  orderStep: number = 1;
  order: Order = new Order();

  constructor(
    private activatedRoute: ActivatedRoute,
    private assetService: AssetService,
    private orderService: OrderService,
    private currentRouter: Router,
    private authenticationService: AuthenticationService
  ) {}

  ngOnInit(): void {
    this.order.personalInformation = new PersonalInformation();

    this.currentId = this.activatedRoute.snapshot.paramMap.get("assetId");
    this.assetService.getAsset(parseInt(this.currentId)).subscribe((data) => {
      this.asset = data;
      this.order.assetId = this.asset.id;
    });
  }

  changeStep(direction: number) {
    this.orderStep += direction;
  }

  public isUserLoggedIn(): boolean {
    return this.authenticationService.tokenExistsAndValid();
  }

  public isButtonClickable(): boolean {
    if (this.orderStep != 2) return true;

    if (
      this.personalInformationComponent == null ||
      this.order.personalInformation.name == undefined ||
      this.order.personalInformation.name.length == 0 ||
      this.order.personalInformation.email == undefined ||
      this.order.personalInformation.email.length == 0 ||
      this.order.personalInformation.email.indexOf("@") < 1 ||
      this.order.personalInformation.city == undefined ||
      this.order.personalInformation.city.length == 0 ||
      this.order.personalInformation.address == undefined ||
      this.order.personalInformation.address.length == 0 ||
      this.order.personalInformation.zipcode == undefined ||
      this.order.personalInformation.zipcode.length == 0 ||
      this.order.startDate == undefined ||
      this.order.endDate == undefined ||
      new Date(this.order.startDate).getTime() >
        new Date(this.order.endDate).getTime()
    )
      return false;

    return true;
  }

  confirmOrder() {
    for (let i = 0; i < this.selectedAccessories.length; i++) {
      if (i == 0)
        this.order.accessories = this.selectedAccessories[i].id.toString();
      else
        this.order.accessories +=
          "," + this.selectedAccessories[i].id.toString();
    }

    let orderAsset = new OrderAsset(this.order, this.asset);

    this.orderService.addOrder(orderAsset).subscribe(
      (data) => {
        this.currentRouter.navigate(["./account/orders/", data.id]);
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
