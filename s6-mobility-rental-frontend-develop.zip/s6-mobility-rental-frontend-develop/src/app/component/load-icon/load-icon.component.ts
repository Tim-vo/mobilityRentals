import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-load-icon',
  templateUrl: './load-icon.component.html',
  styleUrls: ['./load-icon.component.scss']
})
export class LoadIconComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
