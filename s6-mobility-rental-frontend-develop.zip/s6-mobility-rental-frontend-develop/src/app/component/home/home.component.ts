import { Component, Input, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { ActivatedRoute, Router } from "@angular/router";
import { AssetService } from "../../core/service/api/AssetService";
import { Asset } from "../../model/Asset";
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"],
})
export class HomeComponent implements OnInit {
  slogans: string[];
  currentSlogan: string;

  public assetList: Array<Asset>;
  @Input() public minPrice: number = 0;
  @Input() public maxPrice: number = 100000;
  public page: number = 1;
  public amount: number = 20;
  public typeId: number = -1;
  public brands: string = "";
  public ascending: boolean = true;

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    private assetService: AssetService
  ) {
    this.getJSON().subscribe((data) => {
      this.slogans = data;
      this.getCurrentSlogan();
    });
  }

  ngOnInit(): void {
    this.getAssets();
  }

  public getJSON(): Observable<any> {
    return this.http.get("./assets/slogans.json");
  }

  public getCurrentSlogan() {
    this.currentSlogan = this.slogans[
      Math.floor(Math.random() * this.slogans.length)
    ];
    console.log(this.currentSlogan);
  }

  // has to be fixed later
  getAssets() {
    this.assetService
      .getAssetPage(
        this.page,
        this.amount,
        this.typeId,
        this.brands,
        this.minPrice,
        this.maxPrice,
        this.ascending
      )
      .subscribe((assets) => (this.assetList = assets));
  }
}
