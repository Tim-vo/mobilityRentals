import {Component, Input, OnInit} from '@angular/core';
import {TaskService} from "../../../core/service/api/TaskService";
import {SubAssignment} from "../../../model/SubAssignment";
import {replaceImport} from "@angular/core/schematics/migrations/renderer-to-renderer2/migration";
import {AssignmentState} from "../../../model/AssignmentState";

@Component({
  selector: 'app-quotation-request',
  templateUrl: './quotation-request.component.html',
  styleUrls: ['./quotation-request.component.css']
})
export class QuotationRequestComponent implements OnInit {

  @Input() public subAssignments: SubAssignment[];

  constructor(private taskService: TaskService) { }

  ngOnInit(): void {

  }

  SendRequest(price: number, sub: SubAssignment, accepted: boolean) {
    if (!price || price < 0){
      console.log("price not set correctly " +  price);
    } else {
      this.taskService.postResponse(price, sub.id, accepted).subscribe(newSub => {
        this.replace(sub, newSub);
        console.log(newSub);
      });
    }
  }

  enumToString(assignmentEnum: AssignmentState){
    return AssignmentState[assignmentEnum]
  }

  replace(item: SubAssignment, newItem: SubAssignment) {
    const index = this.subAssignments.indexOf(item);
    if (~index) {
      this.subAssignments[index] = newItem;
    }
  }

}
