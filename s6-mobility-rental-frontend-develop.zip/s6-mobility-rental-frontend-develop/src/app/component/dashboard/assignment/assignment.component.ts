import { Component, OnInit } from "@angular/core";
import { TaskService } from "../../../core/service/api/TaskService";
import { Task } from "../../../model/Task";
import { ActivatedRoute, Router } from "@angular/router";
import { AssignmentState } from "src/app/model/AssignmentState";
import { AssignmentType } from "src/app/model/AssignmentType";
import { AuthenticationService } from "src/app/core/service/Auth/authentication.service";

@Component({
  selector: "app-assignment",
  templateUrl: "./assignment.component.html",
  styleUrls: ["./assignment.component.css"],
})
export class AssignmentComponent implements OnInit {
  currentId: string;
  public task: Task;

  constructor(
    private taskService: TaskService,
    private activatedRoute: ActivatedRoute,
    private currentRouter: Router,
    private authService: AuthenticationService
  ) {}

  ngOnInit(): void {
    if (!this.currentId) {
      this.currentId = this.activatedRoute.snapshot.paramMap.get(
        "assignmentId"
      );
    }
    this.taskService.getTask(this.currentId).subscribe(
      (t) => {
        this.task = t;
      },
      (error) => {
        console.error(error);
        this.currentRouter.navigate(["/500"]);
      }
    );
  }

  stateToString(assignmentEnum: AssignmentState) {
    return AssignmentState[assignmentEnum];
  }

  public assignmentTypes(): string[] {
    let keys: string[] = Object.keys(AssignmentType);
    let filteredKeys: string[] = [];
    keys.forEach((key) => {
      if (key.length > 3) {
        filteredKeys.push(key);
      }
    });
    return filteredKeys;
  }

  public getAssignmentTypeClass(type: string): string {
    if (this.task.type > AssignmentType[type]) return "completed";
    else if (this.task.type < AssignmentType[type]) return "future";
    else return "current";
  }

  public isAssigned(): boolean {
    return this.task.assignedAccount === this.authService.getUserId();
  }

  public isCurrentType(type: string): boolean {
    return this.task.type === AssignmentType[type];
  }

  public dealerChosen(task: Task) {
    this.task = task;
  }

  public notifyArrival() {
    this.taskService.notifyArrival(this.task).subscribe((data) => {
      this.task = data;
    });
  }

  public requestRegistration() {
    this.taskService.requestRegistration(this.task).subscribe((data) => {
      this.task = data;
    });
  }

  public grantPermission(given: boolean) {
    this.task.permissionGranted = given;
    this.taskService
      .grantRregistrationPermission(this.task)
      .subscribe((data) => {
        this.task = data;
      });
  }

  public completeRegistration(data) {
    this.task.numberplate = data.numberPlate;
    this.taskService.completeRegistration(this.task).subscribe((data) => {
      this.task = data;
    });
  }
}
