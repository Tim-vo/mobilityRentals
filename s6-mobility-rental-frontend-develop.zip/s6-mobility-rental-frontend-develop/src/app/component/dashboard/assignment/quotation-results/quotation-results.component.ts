import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { SubAssignment } from "src/app/model/SubAssignment";
import { AssignmentState } from "src/app/model/AssignmentState";
import { TaskService } from "src/app/core/service/api/TaskService";
import { Dealer } from "src/app/model/dealer";
import { Task } from "src/app/model/Task";

@Component({
  selector: "app-quotation-results",
  templateUrl: "./quotation-results.component.html",
  styleUrls: ["./quotation-results.component.css"],
})
export class QuotationResultsComponent implements OnInit {
  @Input() task: Task;
  @Input() subassignments: SubAssignment[];
  @Output() dealerChosen = new EventEmitter<Task>();

  constructor(private taskService: TaskService) {}

  ngOnInit(): void {}

  stateToString(assignmentEnum: AssignmentState) {
    return AssignmentState[assignmentEnum];
  }

  public chooseDealer(dealerId: string) {
    let dealer: Dealer = new Dealer();
    dealer.id = dealerId;
    this.taskService.selectDealer(this.task.id, dealer).subscribe((data) => {
      this.dealerChosen.next(data);
    });
  }
}
