import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuotationResultsComponent } from './quotation-results.component';

describe('QuotationResultsComponent', () => {
  let component: QuotationResultsComponent;
  let fixture: ComponentFixture<QuotationResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuotationResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuotationResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
