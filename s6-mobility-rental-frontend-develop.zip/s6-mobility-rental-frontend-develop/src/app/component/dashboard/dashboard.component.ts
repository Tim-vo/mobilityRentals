import { Component, OnInit } from "@angular/core";
import { TaskService } from "../../core/service/api/TaskService";
import { Task } from "../../model/Task";
import { AssignmentState } from "../../model/AssignmentState";
import { SubAssignment } from "../../model/SubAssignment";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"],
})
export class DashboardComponent implements OnInit {
  public taskList: Task[];
  public allTasks: Task[];
  public subAssignments: SubAssignment[];

  public completedCount: number = 0;
  public openCount: number = 0;

  constructor(private taskService: TaskService) {}

  ngOnInit(): void {
    this.taskService.getUserTasks().subscribe((t) => {
      this.taskList = t;
      this.countTasks();
      this.allTasks = this.taskList;
      this.taskList = this.taskList.sort(function (a, b) {
        return (
          new Date(b.lastUpdate).getTime() - new Date(a.lastUpdate).getTime()
        );
      });
      // this.getClosedTasks();
      // console.log("closed " + this.getClosedTasks());
    });
    this.taskService.getSubAssignment().subscribe((s) => {
      this.subAssignments = s;
      this.subAssignments = this.subAssignments.sort(function (a, b) {
        return (
          new Date(b.created).getTime() - new Date(a.created).getTime()
        );
      });
    });
  }

  countTasks() {
    for (let i = 0; i < this.taskList.length; i++) {
      if (this.taskList[i].state == AssignmentState.Closed) {
        this.completedCount++;
      } else if (
        this.taskList[i].state == AssignmentState.InProgress ||
        this.taskList[i].state == AssignmentState.Open ||
        this.taskList[i].state == AssignmentState.Pending
      ) {
        this.openCount++;
      } else {
        console.log(this.taskList[i].state);
        return;
      }
    }
  }

  getAllTasks() {
    this.taskList = this.allTasks;
  }

  getOpenTasks() {
    this.taskList = this.filterTasks(AssignmentState.Pending);
  }

  getClosedTasks() {
    this.taskList = this.filterTasks(AssignmentState.Closed);
  }

  filterTasks(state: AssignmentState): Task[] {
    return this.allTasks.filter((task) => task.state == state);
  }
}
