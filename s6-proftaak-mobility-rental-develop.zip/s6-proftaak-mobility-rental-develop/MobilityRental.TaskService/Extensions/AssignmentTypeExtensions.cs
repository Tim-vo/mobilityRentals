﻿using MobilityRental.AssignmentService.Enums;
using System;

namespace MobilityRental.AssignmentService.Extensions
{
    public static class AssignmentTypeExtensions
    {
        public static AssignmentType NextAssignmentStep(this AssignmentType type)
        {
            switch (type)
            {
                case AssignmentType.CostumerOrdered:
                    return AssignmentType.AssetRequestedFromDealer;
                case AssignmentType.AssetRequestedFromDealer:
                    return AssignmentType.AssetReceivedByDealer;
                case AssignmentType.AssetReceivedByDealer:
                    return AssignmentType.AssetReadyByDealer;
                case AssignmentType.AssetReadyByDealer:
                    return AssignmentType.RegistrationRequested;
                case AssignmentType.RegistrationRequested:
                    return AssignmentType.RegistrationProcessStarted;
                case AssignmentType.RegistrationProcessStarted:
                    return AssignmentType.RegistrationCompleted;
                default:
                    throw new ArgumentOutOfRangeException(nameof(type), type, null);
            }
        }
    }
}
