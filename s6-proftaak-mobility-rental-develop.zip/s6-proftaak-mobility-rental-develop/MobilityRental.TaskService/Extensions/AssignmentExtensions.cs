﻿using MobilityRental.AssignmentService.Enums;
using MobilityRental.AssignmentService.Models;

namespace MobilityRental.AssignmentService.Extensions
{
    public static class AssignmentExtensions
    {
        public static bool AllAccepted(this Assignment assignment)
        {
            bool pass = true;
            foreach (var item in assignment.SubAssignments)
            {
                if (!item.Accepted && pass && item.State != AssignmentState.Closed)
                {
                    pass = false;
                }
            }

            return pass;
        }

        public static SubAssignment HasOneAccepted(this Assignment assignment)
        {
            SubAssignment pass = null;
            foreach (var item in assignment.SubAssignments)
            {
                if (item.Accepted && item.State != AssignmentState.Closed)
                {
                    pass = item;
                }
            }

            return pass;
        }
    }
}
