﻿using MobilityRental.AssignmentService.Enums;
using MobilityRental.AssignmentService.Extensions;
using MobilityRental.AssignmentService.Interfaces;
using MobilityRental.AssignmentService.Models;
using System.Collections.Generic;

namespace MobilityRental.AssignmentService.Logic
{
    public class AssignmentLogic
    {
        private readonly IAssignmentContext _assignmentContext;
        private readonly SubAssignmentLogic _subAssignmentLogic;

        public AssignmentLogic(SubAssignmentLogic subAssignmentLogic, IAssignmentContext assignmentContext)
        {
            _subAssignmentLogic = subAssignmentLogic;
            _assignmentContext = assignmentContext;
        }

        /// <summary>
        /// This is executed AT THE START/ CREATION of the assignment, aka it just enters this step
        /// </summary>
        /// <param name="assignment"></param>
        /// <returns></returns>
        public Assignment StartStep(Assignment assignment)
        {
            switch (assignment.Type)
            {
                case AssignmentType.CostumerOrdered:
                    assignment = RequestAssetsFromDealers(assignment);
                    break;
                case AssignmentType.AssetRequestedFromDealer:
                    assignment = WaitForAsset(assignment);
                    break;
                case AssignmentType.AssetReceivedByDealer:
                    assignment = ReviewAsset(assignment);
                    break;
                case AssignmentType.AssetReadyByDealer:
                    assignment = HandoverToRegistrationPartner(assignment);
                    break;
                case AssignmentType.RegistrationRequested:
                    assignment = RequestPermissionForRegistration(assignment);
                    break;
                case AssignmentType.RegistrationProcessStarted:
                    assignment = WaitForRegisterCompletion(assignment);
                    break;
                case AssignmentType.RegistrationCompleted:
                    break;
            }

            return assignment;
        }

        /// <summary>
        /// Update an assignment, but first check if it has completed. If completed progress it to the next step
        /// </summary>
        /// <param name="assignment"></param>
        /// <returns></returns>
        public Assignment UpdateAssignment(Assignment assignment)
        {
            AssignmentUpdate update;
            if (assignment.HasCompleted())
            {
                ProgressAssignment(assignment);
                StartStep(assignment);
                update = new AssignmentUpdate()
                {
                    Description = "This assignment has been been progressed to its next step."
                };
            }
            else
            {
                update = new AssignmentUpdate()
                {
                    Description = "This assignment has been been updated"
                };
            }

            Assignment result = _assignmentContext.UpdateAssignment(assignment);

            return result;
        }

        /// <summary>
        /// Set the type value to its next value.
        /// </summary>
        /// <param name="assignment"></param>
        public void ProgressAssignment(Assignment assignment)
        {
            //progress the main assignment
            assignment.Type = assignment.Type.NextAssignmentStep();
        }


        private Assignment RequestAssetsFromDealers(Assignment assignment)
        {
            List<SubAssignment> subAssignments = new List<SubAssignment>();

            //give to all dealers aka for loop
            subAssignments.Add(new SubAssignment()
            {
                Description = "An asset has been requested, do you have this available?"
            });

            //Add a sub assignment with the accepted subassignment, and assign the correct users
            _subAssignmentLogic.CreateSubAssignment(assignment.Id, subAssignments);

            return assignment;
        }

        private Assignment WaitForAsset(Assignment assignment)
        {
            List<SubAssignment> subAssignments = new List<SubAssignment>();

            SubAssignment subAssignment = assignment.HasOneAccepted();

            subAssignment.State = AssignmentState.Closed;
            assignment.AssignedAccount = subAssignment.AssignedAccount;

            //give to the one specific dealer
            subAssignments.Add(new SubAssignment()
            {
                Description = "Waiting for asset delivery.",
                AssignedAccount = subAssignment.AssignedAccount
            });

            //Add a sub assignment with the accepted subassignment, and assign the correct users
            _subAssignmentLogic.CreateSubAssignment(assignment.Id, subAssignments);

            return assignment;
        }

        private Assignment ReviewAsset(Assignment assignment)
        {
            List<SubAssignment> subAssignments = new List<SubAssignment>();

            SubAssignment subAssignment = assignment.HasOneAccepted();
            subAssignment.State = AssignmentState.Closed;

            //give to the one specific dealer
            subAssignments.Add(new SubAssignment()
            {
                Description = "Review the asset and verify the asset.",
                AssignedAccount = subAssignment.AssignedAccount
            });

            //Add a sub assignment with the accepted subassignment, and assign the correct users
            _subAssignmentLogic.CreateSubAssignment(assignment.Id, subAssignments);

            return assignment;
        }

        private Assignment HandoverToRegistrationPartner(Assignment assignment)
        {
            List<SubAssignment> subAssignments = new List<SubAssignment>();

            SubAssignment subAssignment = assignment.HasOneAccepted();
            subAssignment.State = AssignmentState.Closed;

            //Get a specific registration partner to handle this process
            subAssignments.Add(new SubAssignment()
            {
                Description = "Verify receival of asset.",
            });

            //Add a sub assignment with the accepted subassignment, and assign the correct users
            _subAssignmentLogic.CreateSubAssignment(assignment.Id, subAssignments);

            return assignment;
        }

        private Assignment RequestPermissionForRegistration(Assignment assignment)
        {
            List<SubAssignment> subAssignments = new List<SubAssignment>();

            SubAssignment subAssignment = assignment.HasOneAccepted();
            subAssignment.State = AssignmentState.Closed;

            //Get a specific registration partner to handle this process
            subAssignments.Add(new SubAssignment()
            {
                Description = "Approve the registration-start.",
            });

            //Add a sub assignment with the accepted subassignment, and assign the correct users
            _subAssignmentLogic.CreateSubAssignment(assignment.Id, subAssignments);

            return assignment;
        }

        public Assignment WaitForRegisterCompletion(Assignment assignment)
        {
            assignment.State = AssignmentState.Closed;

            return assignment;
        }
    }
}
