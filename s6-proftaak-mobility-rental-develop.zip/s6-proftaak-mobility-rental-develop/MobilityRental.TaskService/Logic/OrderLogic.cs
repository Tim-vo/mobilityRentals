﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MobilityRental.AssignmentService.Interfaces;
using MobilityRental.AssignmentService.Models;
using MobilityRental.Common.Configuration;
using MobilityRental.Common.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace MobilityRental.AssignmentService.Logic
{
    public class OrderLogic
    {
        #region Fields
        private readonly ServerTokenConfiguration serverTokenConfiguration;
        private readonly IAssignmentContext assignmentContext;
        private readonly ILogger<OrderLogic> logger;
        private readonly Random random;
        #endregion

        #region Setup
        public OrderLogic(IOptions<ServerTokenConfiguration> serverTokenConfiguration, IAssignmentContext assignmentContext, ILogger<OrderLogic> logger)
        {
            this.serverTokenConfiguration = serverTokenConfiguration.Value;
            this.assignmentContext = assignmentContext;
            this.logger = logger;
            random = new Random();
        }
        #endregion

        #region Public
        public void HandleNewOrder(OrderAsset orderAsset)
        {
            List<Account> dealers = GetAccountsWithRole("{\"Name\":\"Dealer\"}");
            List<Account> employees = GetAccountsWithRole("{\"Name\":\"Employee\"}");

            OrderInformation orderInformation = ConvertOrderAssetToOrderInformation(orderAsset);
            List<SubAssignment> subAssignments = CreateSubassignments(dealers, orderInformation);
            Assignment assignment = CreateAssignment(employees, subAssignments, orderInformation);

            assignmentContext.CreateAssignment(assignment);
            logger.LogInformation("Assignments created.");
        }
        #endregion

        #region Private
        private List<Account> GetAccountsWithRole(string role)
        {
            byte[] body = Encoding.UTF8.GetBytes(role);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create($"{serverTokenConfiguration.GatewayUrl}/account-api/role");
            logger.LogInformation($"URI: {request.RequestUri.AbsoluteUri}");
            request.Headers.Add("Authorization", $"bearer {serverTokenConfiguration.Jwt}");
            request.Method = "POST";
            request.ContentLength = body.Length;
            request.ContentType = "application/json";
            Stream stream = request.GetRequestStream();
            stream.Write(body, 0, body.Length);
            stream.Close();

            WebResponse response = request.GetResponse();

            string responseBody = "";
            using (stream = response.GetResponseStream())
            {
                StreamReader reader = new StreamReader(stream);
                responseBody = reader.ReadToEnd();
            }

            response.Close();

            return JsonConvert.DeserializeObject<List<Account>>(responseBody);
        }

        private OrderInformation ConvertOrderAssetToOrderInformation(OrderAsset orderAsset)
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (string selectedAccessoryId in orderAsset.GetOrder.Accessories.Split(','))
            {
                foreach (Accessory accessory in orderAsset.GetAsset.Accessories)
                {
                    if (accessory.Id.Equals(Convert.ToInt32(selectedAccessoryId)))
                    {
                        if (stringBuilder.Length > 0)
                            stringBuilder.Append($",{accessory.Name}");
                        else
                            stringBuilder.Append(accessory.Name);
                    }
                }
            }

            OrderInformation orderInformation = new OrderInformation()
            {
                OrderNumber = orderAsset.GetOrder.Number,
                OrderDate = orderAsset.GetOrder.OrderDate,
                StartDate = orderAsset.GetOrder.StartDate,
                EndDate = orderAsset.GetOrder.EndDate,
                AssetName = orderAsset.GetAsset.Name,
                SerialNumber = orderAsset.GetAsset.SerialNumber,
                Accessories = stringBuilder.ToString()
            };

            return orderInformation;
        }

        private List<SubAssignment> CreateSubassignments(List<Account> dealers, OrderInformation orderInformation)
        {
            List<SubAssignment> subAssignments = new List<SubAssignment>();

            foreach (Account account in dealers)
            {
                SubAssignment subAssignment = new SubAssignment()
                {
                    Name = "Asset quotation request",
                    Description = "A request for a quotation has been made.",
                    AssignedAccount = account.Id,
                    State = Enums.AssignmentState.Open,
                    OrderInformationSet = orderInformation,
                    Created = DateTime.Now
                };

                subAssignments.Add(subAssignment);
            }

            return subAssignments;
        }

        private Assignment CreateAssignment(List<Account> employees, List<SubAssignment> subAssignments, OrderInformation orderInformation)
        {
            Assignment assignment = new Assignment()
            {
                State = Enums.AssignmentState.Pending,
                Type = Enums.AssignmentType.CostumerOrdered,
                CompletionType = Enums.AssignmentCompletionType.NONE,
                Name = "New order",
                Description = "A new order has been made by a customer.",
                AssignedAccount = SelectEmployee(employees).Id,
                SubAssignments = subAssignments,
                OrderNumber = orderInformation.OrderNumber,
                OrderInformationSet = orderInformation
            };

            return assignment;
        }

        private Account SelectEmployee(List<Account> employees)
        {
            return employees[random.Next(0, employees.Count)];
        }
        #endregion
    }
}
