﻿using MobilityRental.AssignmentService.Interfaces;
using MobilityRental.AssignmentService.Models;
using System.Collections.Generic;

namespace MobilityRental.AssignmentService.Logic
{
    public class SubAssignmentLogic
    {
        private readonly IAssignmentContext _assignmentContext;
        private readonly ISubAssignmentContext _subAssignmentContext;

        public SubAssignmentLogic(IAssignmentContext assignmentContext, ISubAssignmentContext subAssignmentContext)
        {
            _assignmentContext = assignmentContext;
            _subAssignmentContext = subAssignmentContext;
        }

        public Assignment CreateSubAssignment(string assignmentId, List<SubAssignment> subAssignments)
        {
            Assignment assignment = _assignmentContext.GetAssignment(assignmentId);

            if (assignment != null)
            {
                if (assignment.SubAssignments == null)
                {
                    assignment.SubAssignments = new List<SubAssignment>();
                }
                //TODO: Mark fix help
                var x = _subAssignmentContext.CreateSubAssignments(assignmentId, subAssignments);
                assignment.SubAssignments.AddRange(x);


                var update = new AssignmentUpdate
                {
                    Description = "A new subtask was added"
                };
                return _assignmentContext.UpdateAssignment(assignment);
            }
            else
            {
                return null;
            }
        }
    }
}
