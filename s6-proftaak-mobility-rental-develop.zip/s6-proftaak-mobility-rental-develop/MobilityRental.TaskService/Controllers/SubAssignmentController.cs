﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MobilityRental.AssignmentService.Interfaces;
using MobilityRental.AssignmentService.Logic;
using MobilityRental.AssignmentService.Models;
using MobilityRental.Common.Extensions;
using System.Collections.Generic;
using System.Security.Claims;

namespace MobilityRental.AssignmentService.Controllers
{
    [Route("subassignment")]
    [Authorize]
    [ApiController]
    public class SubAssignmentController : ControllerBase
    {
        private readonly ISubAssignmentContext _subAssignmentContext;
        private readonly SubAssignmentLogic _assignmentLogic;

        public SubAssignmentController(ISubAssignmentContext subAssignmentContext, SubAssignmentLogic assignmentLogic)
        {
            _subAssignmentContext = subAssignmentContext;
            _assignmentLogic = assignmentLogic;
        }

        /// <summary>
        /// Get an individual subassignment
        /// </summary>
        /// <param name="id">The id of a subassignment</param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public SubAssignment GetSubAssignment(string id)
        {
            return _subAssignmentContext.GetSubAssignment(id);
        }

        [HttpGet("user")]
        public List<SubAssignment> GetAllUserSubAssignments()
        {
            string userId = User.GetUserId();
            if (!string.IsNullOrEmpty(userId))
            {
                return _subAssignmentContext.GetUserSubAssignments(userId);
            }

            return null;
        }

        /// <summary>
        /// Create (multiple) subassignments
        /// </summary>
        /// <param name="assignmentId">ID of assignment</param>
        /// <param name="subAssignments">List of new subassignments</param>
        /// <returns></returns>
        [HttpPost("{assignmentId}")]
        public List<SubAssignment> CreateSubAssignment(string assignmentId, List<SubAssignment> subAssignments)
        {
            return _subAssignmentContext.CreateSubAssignments(assignmentId, subAssignments);
        }

        [HttpPut]
        public SubAssignment UpdateSubAssignment(SubAssignment subAssignment)
        {
            return _subAssignmentContext.UpdateSubAssignment(subAssignment);
        }

        /// <summary>
        /// Also calls the assignment to update
        /// </summary>
        /// <returns></returns>
        [HttpPut("{id}/accept")]
        [Authorize(Roles = "Dealer")]
        public SubAssignment AcceptAssignment(string id, [FromBody] Quotation quotation)
        {
            SubAssignment subAssignment = _subAssignmentContext.GetSubAssignment(id);

            if (subAssignment.AssignedAccount.Equals(User.FindFirst(ClaimTypes.NameIdentifier)?.Value) && subAssignment.State == Enums.AssignmentState.Open)
            {
                subAssignment.Accepted = quotation.Accepted;
                subAssignment.Price = quotation.Price;
                if (quotation.Accepted)
                {
                    subAssignment.State = Enums.AssignmentState.Pending;
                    subAssignment.Name = "Quotation send";
                    subAssignment.Description = "Your quotation has been send to the company. Thank you for your interest.";
                }
                else
                {
                    subAssignment.State = Enums.AssignmentState.Closed;
                    subAssignment.Name = "Quotation declined";
                    subAssignment.Description = "You declined the quotation, thank you for your time.";
                }
                _subAssignmentContext.UpdateSubAssignment(subAssignment);

                return subAssignment;
            }
            else
                return null;
        }

        /// <summary>
        /// Delete a subassignment
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        public bool DeleteSubAssignment(string id)
        {
            return _subAssignmentContext.DeleteSubAssignment(id);
        }
    }
}