﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MobilityRental.AssignmentService.Enums;
using MobilityRental.AssignmentService.Interfaces;
using MobilityRental.AssignmentService.Logic;
using MobilityRental.AssignmentService.Models;
using MobilityRental.Common.Extensions;
using System.Collections.Generic;
using System.Security.Claims;

namespace MobilityRental.AssignmentService.Controllers
{
    [Route("assignment")]
    [Authorize]
    [ApiController]
    public class AssignmentController : ControllerBase
    {
        private readonly AssignmentLogic _assignmentLogic;
        private readonly IAssignmentContext _assignmentContext;
        private readonly ILogger<AssignmentController> _logger;

        public AssignmentController(IAssignmentContext assignmentContext, AssignmentLogic assignmentLogic, ILogger<AssignmentController> logger)
        {
            _assignmentContext = assignmentContext;
            _assignmentLogic = assignmentLogic;
            _logger = logger;
        }

        /// <summary>
        /// Retrieve an asset based on the users jwt token/userid
        /// </summary>
        /// <returns></returns>
        [HttpGet("user")]
        public List<Assignment> GetAllUserAssignments()
        {
            string userId = User.GetUserId();
            if (!string.IsNullOrEmpty(userId))
            {
                return _assignmentContext.GetAllUserAssignments(userId);
            }

            return null;
        }

        /// <summary>
        /// Retrieve an asset on id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public Assignment GetAssignment(string id)
        {
            return _assignmentContext.GetAssignment(id);
        }

        /// <summary>
        /// Update the assignment an assignments contents
        /// </summary>
        /// <param name="assignment"></param>
        /// <returns></returns>
        [HttpPut]
        public Assignment UpdateAssignment(Assignment assignment)
        {
            return _assignmentContext.UpdateAssignment(assignment);
        }

        /// <summary>
        /// Create a new assignment
        /// </summary>
        /// <param name="assignment"></param>
        /// <returns></returns>
        [HttpPost]
        public Assignment CreateAssignment(Assignment assignment)
        {
            Assignment newAssignment = _assignmentContext.CreateAssignment(assignment);
            _assignmentLogic.StartStep(newAssignment);
            return newAssignment;
        }

        /// <summary>
        /// Delete an entire assignment
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        public bool DeleteAssignment(string id)
        {
            return _assignmentContext.DeleteAssignment(id);
        }

        [HttpPost("{id}/select-dealer")]
        [Authorize(Roles = "Employee")]
        public Assignment SelectDealer(string id, [FromBody] Account dealer)
        {
            Assignment assignment = _assignmentContext.GetAssignment(id);

            if (assignment.AssignedAccount.Equals(User.FindFirst(ClaimTypes.NameIdentifier)?.Value) && assignment.State == AssignmentState.Pending)
            {
                foreach (SubAssignment subAssignment in assignment.SubAssignments)
                {
                    if (subAssignment.AssignedAccount.Equals(dealer.Id))
                    {
                        subAssignment.State = AssignmentState.InProgress;
                        subAssignment.Name = "Quotation accepted";
                        subAssignment.Description = "Your quotation has been accepted by the company.";
                    }
                    else
                    {
                        subAssignment.State = AssignmentState.Closed;
                        subAssignment.Name = "Quotation declined";
                        subAssignment.Description = "The company decided to go with another dealer. Thank you for your interest.";
                    }
                }

                assignment.ReportingAccount = assignment.AssignedAccount;
                assignment.AssignedAccount = dealer.Id;
                _assignmentLogic.ProgressAssignment(assignment);
                _assignmentContext.UpdateAssignment(assignment);

                return assignment;
            }
            else
                return null;
        }

        [HttpPost("notify-arrival")]
        public Assignment NotifyAssetArrival(Assignment activeAssignment)
        {
            Assignment assignment = _assignmentContext.GetAssignment(activeAssignment.Id);

            if (assignment.Type == AssignmentType.AssetRequestedFromDealer)
            {
                _assignmentLogic.ProgressAssignment(assignment);
                _assignmentContext.UpdateAssignment(assignment);
            }
            return assignment;
        }

        [HttpPost("request-registration")]
        public Assignment RequestRegistrationStart(Assignment activeAssignment)
        {
            Assignment assignment = _assignmentContext.GetAssignment(activeAssignment.Id);

            if (assignment.Type == AssignmentType.AssetReceivedByDealer || assignment.Type == AssignmentType.AssetReadyByDealer)
            {
                assignment.Type = AssignmentType.RegistrationRequested;
                string employee = assignment.ReportingAccount;
                assignment.ReportingAccount = assignment.AssignedAccount;
                assignment.AssignedAccount = employee;
                _assignmentContext.UpdateAssignment(assignment);
            }
            return assignment;
        }

        [HttpPost("handle-request")]
        public Assignment HandleRegistrationStart(Assignment activeAssignment)
        {
            Assignment assignment = _assignmentContext.GetAssignment(activeAssignment.Id);
            assignment.PermissionGranted = activeAssignment.PermissionGranted;

            if (assignment.Type == AssignmentType.RegistrationRequested)
            {
                if (assignment.PermissionGranted)
                {
                    assignment.Type = AssignmentType.RegistrationProcessStarted;
                }
                else
                {
                    assignment.Type = AssignmentType.AssetReadyByDealer;
                    _logger.LogInformation("Requested permission was denied");
                }

                string dealer = assignment.ReportingAccount;
                assignment.ReportingAccount = assignment.AssignedAccount;
                assignment.AssignedAccount = dealer;
                _assignmentContext.UpdateAssignment(assignment);
            }
            else
            {
                _logger.LogInformation("No registration request found");
            }
            return assignment;
        }

        [HttpPut("registration-complete")]
        public Assignment CompleteRegistration(Assignment activeAssignment)
        {
            Assignment assignment = _assignmentContext.GetAssignment(activeAssignment.Id);
            assignment.Numberplate = activeAssignment.Numberplate;

            if (_assignmentContext.CompleteRegistration(assignment))
                assignment.Type = AssignmentType.RegistrationCompleted;
            _assignmentLogic.WaitForRegisterCompletion(assignment);
            _assignmentContext.UpdateAssignment(assignment);
            return assignment;
        }
    }
}