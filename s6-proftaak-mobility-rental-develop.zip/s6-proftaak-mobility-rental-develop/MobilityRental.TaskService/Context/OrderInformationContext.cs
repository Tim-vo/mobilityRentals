﻿using MobilityRental.AssignmentService.Interfaces;
using MobilityRental.AssignmentService.Models;

namespace MobilityRental.AssignmentService.Context
{
    public class OrderInformationContext : IOrderInformationContext
    {
        private EntityContext entityContext;

        public OrderInformationContext(EntityContext entityContext)
        {
            this.entityContext = entityContext;
        }

        public OrderInformation CreateOrderInformation(OrderInformation orderInformation)
        {
            entityContext.Add(orderInformation);
            entityContext.SaveChanges();
            return orderInformation;
        }
    }
}
