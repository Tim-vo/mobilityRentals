﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MobilityRental.AssignmentService.Models;
using MobilityRental.Common.Configuration;

namespace MobilityRental.AssignmentService.Context
{
    public class EntityContext : DbContext
    {
        private readonly IOptions<SQLSettings> _sqlSettings;
        public DbSet<Assignment> BaseAssignments { get; set; }
        public DbSet<SubAssignment> SubAssignments { get; set; }
        public DbSet<OrderInformation> OrderInformations { get; set; }

        public EntityContext(IOptions<SQLSettings> _SqlSettings, ILogger<EntityContext> logger)
        {
            _sqlSettings = _SqlSettings;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_sqlSettings.Value.ConnectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("Assignment");
        }
    }
}
