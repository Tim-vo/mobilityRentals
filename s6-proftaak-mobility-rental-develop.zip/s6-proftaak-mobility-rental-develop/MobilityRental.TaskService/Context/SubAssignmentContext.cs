﻿using Microsoft.EntityFrameworkCore;
using MobilityRental.AssignmentService.Interfaces;
using MobilityRental.AssignmentService.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MobilityRental.AssignmentService.Context
{
    public class SubAssignmentContext : ISubAssignmentContext
    {
        private readonly EntityContext entityContext;

        public SubAssignmentContext(EntityContext entityContext)
        {
            this.entityContext = entityContext;
        }

        public SubAssignment GetSubAssignment(string id)
        {
            var result = entityContext.SubAssignments.Where(a => a.Id == id).Include(a => a.OrderInformationSet);
            SubAssignment asset = null;
            if (result.Any())
            {
                asset = result.First();
            }
            return asset;
        }


        public List<SubAssignment> GetUserSubAssignments(string userId)
        {
            var result = entityContext.SubAssignments.Include(i => i.OrderInformationSet).Where(a => a.AssignedAccount == userId);
            return result.ToList();
        }

        public List<SubAssignment> CreateSubAssignments(string assignmentId, List<SubAssignment> subAssignments)
        {
            entityContext.AddRange(subAssignments);
            entityContext.SaveChanges();
            return subAssignments;
        }
        public SubAssignment UpdateSubAssignment(SubAssignment assignment)
        {
            assignment.LastUpdate = DateTime.Now;
            entityContext.Update(assignment);
            entityContext.SaveChanges();
            return assignment; //Id is filled by entity
        }
        public bool DeleteSubAssignment(string id)
        {
            var result = GetSubAssignment(id);

            if (result != null)
            {
                entityContext.Remove(result);
                entityContext.SaveChanges();
                return true;
            }

            return false;
        }

        public SubAssignment AcceptAssignment(string id)
        {
            return null;
        }
    }
}
