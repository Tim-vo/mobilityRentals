﻿using Microsoft.EntityFrameworkCore;
using MobilityRental.AssignmentService.Interfaces;
using MobilityRental.AssignmentService.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MobilityRental.AssignmentService.Context
{
    public class AssignmentContext : IAssignmentContext
    {
        private readonly EntityContext entityContext;

        public AssignmentContext(EntityContext entityContext)
        {
            this.entityContext = entityContext;
        }

        public List<Assignment> GetAllUserAssignments(string userId)
        {
            var result = entityContext.BaseAssignments.Where(a => a.AssignedAccount == userId || a.ReportingAccount == userId);
            return result.ToList();
        }

        public Assignment GetAssignment(string id)
        {
            var result = entityContext.BaseAssignments.Where(a => a.Id == id).Include(item => item.SubAssignments).Include(item => item.Updates).Include(a => a.OrderInformationSet);
            Assignment asset = null;
            if (result.Any())
            {
                asset = result.First();
            }
            return asset;
        }

        public Assignment CreateAssignment(Assignment assignment)
        {
            assignment.Id = null;
            assignment.Created = DateTime.Now;
            assignment.LastUpdate = DateTime.Now;

            entityContext.Add(assignment);
            entityContext.SaveChanges();
            return assignment; //Id is filled by entity
        }

        public Assignment UpdateAssignment(Assignment assignment)
        {
            AssignmentUpdate update = new AssignmentUpdate();
            update.Created = DateTime.Now;
            assignment.LastUpdate = DateTime.Now;

            if (assignment.Updates == null)
            {
                assignment.Updates = new List<AssignmentUpdate>();
            }
            assignment.Updates.Add(update);

            entityContext.SaveChanges();
            return assignment;
        }

        public bool DeleteAssignment(string id)
        {
            var result = GetAssignment(id);

            if (result != null)
            {
                entityContext.Remove(result);
                entityContext.SaveChanges();
                return true;
            }

            return false;
        }

        public bool CompleteRegistration(Assignment assignment)
        {
            bool isDone = false;
            if (!string.IsNullOrEmpty(assignment.Numberplate))
            {
                UpdateAssignment(assignment);
                isDone = true;
            }
            return isDone;
        }
    }
}
