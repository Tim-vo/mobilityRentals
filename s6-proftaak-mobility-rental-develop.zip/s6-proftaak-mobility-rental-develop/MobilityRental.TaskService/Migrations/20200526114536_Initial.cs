﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;

namespace MobilityRental.AssignmentService.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "Assignment");

            migrationBuilder.CreateTable(
                name: "OrderInformations",
                schema: "Assignment",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    OrderNumber = table.Column<string>(nullable: true),
                    OrderDate = table.Column<DateTime>(nullable: false),
                    StartDate = table.Column<DateTime>(nullable: false),
                    EndDate = table.Column<DateTime>(nullable: false),
                    AssetName = table.Column<string>(nullable: true),
                    SerialNumber = table.Column<string>(nullable: true),
                    Accessories = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderInformations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BaseAssignments",
                schema: "Assignment",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    State = table.Column<int>(nullable: false),
                    Type = table.Column<int>(nullable: false),
                    CompletionType = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    AssignedAccount = table.Column<string>(nullable: true),
                    ReportingAccount = table.Column<string>(nullable: true),
                    OrderNumber = table.Column<string>(nullable: true),
                    OrderInformationSetId = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    LastUpdate = table.Column<DateTime>(nullable: false),
                    Numberplate = table.Column<string>(nullable: true),
                    PermissionGranted = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BaseAssignments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BaseAssignments_OrderInformations_OrderInformationSetId",
                        column: x => x.OrderInformationSetId,
                        principalSchema: "Assignment",
                        principalTable: "OrderInformations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "AssignmentUpdate",
                schema: "Assignment",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    Updater = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    NewReporter = table.Column<string>(nullable: true),
                    OldReporter = table.Column<string>(nullable: true),
                    NewAssigned = table.Column<string>(nullable: true),
                    OldAssigned = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    AssignmentId = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AssignmentUpdate", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AssignmentUpdate_BaseAssignments_AssignmentId",
                        column: x => x.AssignmentId,
                        principalSchema: "Assignment",
                        principalTable: "BaseAssignments",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "SubAssignments",
                schema: "Assignment",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    AssignedAccount = table.Column<string>(nullable: true),
                    State = table.Column<int>(nullable: false),
                    Accepted = table.Column<bool>(nullable: false),
                    Price = table.Column<decimal>(nullable: false),
                    OrderInformationSetId = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: false),
                    LastUpdate = table.Column<DateTime>(nullable: false),
                    AssignmentId = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SubAssignments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SubAssignments_BaseAssignments_AssignmentId",
                        column: x => x.AssignmentId,
                        principalSchema: "Assignment",
                        principalTable: "BaseAssignments",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_SubAssignments_OrderInformations_OrderInformationSetId",
                        column: x => x.OrderInformationSetId,
                        principalSchema: "Assignment",
                        principalTable: "OrderInformations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AssignmentUpdate_AssignmentId",
                schema: "Assignment",
                table: "AssignmentUpdate",
                column: "AssignmentId");

            migrationBuilder.CreateIndex(
                name: "IX_BaseAssignments_OrderInformationSetId",
                schema: "Assignment",
                table: "BaseAssignments",
                column: "OrderInformationSetId");

            migrationBuilder.CreateIndex(
                name: "IX_SubAssignments_AssignmentId",
                schema: "Assignment",
                table: "SubAssignments",
                column: "AssignmentId");

            migrationBuilder.CreateIndex(
                name: "IX_SubAssignments_OrderInformationSetId",
                schema: "Assignment",
                table: "SubAssignments",
                column: "OrderInformationSetId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AssignmentUpdate",
                schema: "Assignment");

            migrationBuilder.DropTable(
                name: "SubAssignments",
                schema: "Assignment");

            migrationBuilder.DropTable(
                name: "BaseAssignments",
                schema: "Assignment");

            migrationBuilder.DropTable(
                name: "OrderInformations",
                schema: "Assignment");
        }
    }
}
