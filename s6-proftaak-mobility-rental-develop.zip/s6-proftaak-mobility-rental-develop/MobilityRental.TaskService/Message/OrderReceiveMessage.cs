﻿using System;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MobilityRental.AssignmentService.Logic;
using MobilityRental.AssignmentService.Models;
using MobilityRental.Common.Configuration;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace MobilityRental.AssignmentService.Message
{
    public class OrderReceiveMessage : DefaultBasicConsumer
    {
        private MessageSettings messageSettings;
        private ConnectionFactory factory;
        private IConnection connection;
        private IModel channel;
        private string queueName;
        private EventingBasicConsumer consumer;
        private OrderLogic orderLogic;
        private readonly ILogger<OrderReceiveMessage> logger;

        public OrderReceiveMessage(IOptions<MessageSettings> messageSettings, OrderLogic orderLogic, ILogger<OrderReceiveMessage> logger)
        {
            this.messageSettings = messageSettings.Value;
            this.orderLogic = orderLogic;
            this.logger = logger;

            try
            {
                this.factory = new ConnectionFactory() { HostName = this.messageSettings.HostName };
                this.connection = this.factory.CreateConnection();
                this.channel = this.connection.CreateModel();
            }
            catch(Exception e)
            {
                logger.LogError(e.Message);
            }
        }

        public void StartMessageReceiver()
        {
            logger.LogInformation("Starting order listener.");
            channel.ExchangeDeclare(exchange: this.messageSettings.Channel, type: ExchangeType.Fanout);

            this.queueName = channel.QueueDeclare().QueueName;
            this.channel.QueueBind(queue: this.queueName,
                exchange: this.messageSettings.Channel,
                routingKey: "");

            this.consumer = new EventingBasicConsumer(this.channel);
            this.consumer.Received += this.ReceiveMessage;
            this.channel.BasicConsume(queue: this.queueName,
                    autoAck: true,
                    consumer: this.consumer);

            logger.LogInformation("Listening for new orders.");
        }

        private void ReceiveMessage(object sender, BasicDeliverEventArgs e)
        {
            logger.LogInformation("New order received.");
            try
            {
                var body = e.Body;
                var message = Encoding.UTF8.GetString(body.ToArray());
                OrderAsset orderAsset = JsonSerializer.Deserialize(message, typeof(OrderAsset)) as OrderAsset;

                orderLogic.HandleNewOrder(orderAsset);
            }
            catch (Exception ex)
            {
                logger.LogError(ex.ToString());
            }
        }
    }
}
