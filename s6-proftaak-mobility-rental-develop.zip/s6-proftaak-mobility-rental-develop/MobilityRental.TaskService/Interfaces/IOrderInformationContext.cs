﻿using MobilityRental.AssignmentService.Models;

namespace MobilityRental.AssignmentService.Interfaces
{
    public interface IOrderInformationContext
    {
        OrderInformation CreateOrderInformation(OrderInformation orderInformation);
    }
}
