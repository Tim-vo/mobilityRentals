﻿using MobilityRental.AssignmentService.Models;
using System.Collections.Generic;

namespace MobilityRental.AssignmentService.Interfaces
{
    public interface IAssignmentContext
    {
        List<Assignment> GetAllUserAssignments(string userId);
        Assignment GetAssignment(string id);
        Assignment UpdateAssignment(Assignment assignment);
        Assignment CreateAssignment(Assignment assignment);
        bool DeleteAssignment(string id);
        bool CompleteRegistration(Assignment assignment);
    }
}
