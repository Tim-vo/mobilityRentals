﻿using MobilityRental.AssignmentService.Models;
using System.Collections.Generic;

namespace MobilityRental.AssignmentService.Interfaces
{
    public interface ISubAssignmentContext
    {
        SubAssignment GetSubAssignment(string id);

        List<SubAssignment> GetUserSubAssignments(string id);
        List<SubAssignment> CreateSubAssignments(string assignmentId, List<SubAssignment> subAssignments);
        SubAssignment UpdateSubAssignment(SubAssignment subAssignment);
        SubAssignment AcceptAssignment(string id);
        bool DeleteSubAssignment(string id);
    }
}
