﻿namespace MobilityRental.AssignmentService.Enums
{
    public enum AssignmentState
    {
        Open,
        Closed,
        InProgress,
        Pending,
        Blocked,
        Duplicate
    }
}
