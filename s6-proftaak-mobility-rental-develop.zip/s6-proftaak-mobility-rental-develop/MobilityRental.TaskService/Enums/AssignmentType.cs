﻿namespace MobilityRental.AssignmentService.Enums
{
    public enum AssignmentType
    {
        /// <summary>
        /// Used when an asset is ordered by a costumer
        /// </summary>
        CostumerOrdered,

        /// <summary>
        /// When the employee chooses a dealer to retrieve the asset from 
        /// </summary>
        AssetRequestedFromDealer,

        /// <summary>
        /// The asset has been received by the dealer
        /// </summary>
        AssetReceivedByDealer,

        /// <summary>
        /// The asset has been received and reviewed by the dealer
        /// </summary>
        AssetReadyByDealer,
        /// <summary>
        /// The request for registration is sent to the employee
        /// </summary>
        RegistrationRequested,

        /// <summary>
        /// An employee has given permission to start the registration process
        /// </summary>
        RegistrationProcessStarted,

        /// <summary>
        /// The registration has completed
        /// </summary>
        RegistrationCompleted,
    }
}
