﻿namespace MobilityRental.AssignmentService.Enums
{
    public enum AssignmentCompletionType
    {
        ALL,
        ONE,
        NONE
    }
}
