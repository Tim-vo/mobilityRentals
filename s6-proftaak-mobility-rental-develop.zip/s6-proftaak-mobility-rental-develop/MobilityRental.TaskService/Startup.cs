using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using MobilityRental.AssignmentService.Context;
using MobilityRental.AssignmentService.Interfaces;
using MobilityRental.AssignmentService.Logic;
using MobilityRental.AssignmentService.Message;
using MobilityRental.Common.Configuration;
using NSwag;
using NSwag.Generation.Processors.Security;
using Serilog;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;

namespace MobilityRental.AssignmentService
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<SQLSettings>(Configuration.GetSection("SQLSettings"));
            services.Configure<MessageSettings>(Configuration.GetSection("MessageSettings"));
            services.Configure<ServerTokenConfiguration>(Configuration.GetSection("ServerTokenConfiguration"));

            services.AddLogging(loggingBuilder => loggingBuilder.AddSerilog(dispose: true));

            services.AddSwaggerDocument(document =>
            {
                document.Title = "Channel API";

                document.AddSecurity("bearer", Enumerable.Empty<string>(), new OpenApiSecurityScheme
                {
                    Type = OpenApiSecuritySchemeType.ApiKey,
                    Name = "Authorization",
                    In = OpenApiSecurityApiKeyLocation.Header,
                    Description = "Type into the textbox: Bearer {your JWT token}."
                });

                document.OperationProcessors.Add(
                    new AspNetCoreOperationSecurityScopeProcessor("bearer"));
            });

            services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader();
            }));

            // ===== Add our DbContext ========
            services.AddDbContext<EntityContext>();
            services.AddTransient<EntityContext>();

            services.AddTransient<IAssignmentContext, AssignmentContext>();
            services.AddTransient<ISubAssignmentContext, SubAssignmentContext>();
            services.AddTransient<IOrderInformationContext, OrderInformationContext>();
            services.AddSingleton<OrderReceiveMessage, OrderReceiveMessage>();

            services.AddTransient<AssignmentLogic>();
            services.AddTransient<SubAssignmentLogic>();
            services.AddTransient<OrderLogic>();

            services.AddAuthorization(options =>
            {
                // options.
            });

            // ===== Add Jwt Authentication ========
            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear(); // => remove default claims
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;

            }).AddJwtBearer(cfg =>
            {
                cfg.RequireHttpsMetadata = false;
                cfg.SaveToken = true;
                cfg.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidIssuer = Configuration["JwtIssuer"],
                    ValidAudience = Configuration["JwtIssuer"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["JwtKey"])),
                    ClockSkew = TimeSpan.Zero // remove delay of token when expire
                };
            });

            services.AddControllers();
        }

        public void ApplyMigrations(EntityContext context)
        {
            if (context.Database.GetPendingMigrations().Any())
            {
                context.Database.Migrate();
            }
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, EntityContext dbContext)
        {
            app.ApplicationServices.GetService<OrderReceiveMessage>().StartMessageReceiver();

            app.UseCors("MyPolicy");

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseOpenApi();
            app.UseSwaggerUi3();

            Console.WriteLine("Migrating database...");
            ApplyMigrations(dbContext);
            Console.WriteLine("Checking database");

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
