﻿using MobilityRental.AssignmentService.Enums;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MobilityRental.AssignmentService.Models
{
    public class SubAssignment
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string AssignedAccount { get; set; }
        public AssignmentState State { get; set; }
        public bool Accepted { get; set; }
        public decimal Price { get; set; }
        public OrderInformation OrderInformationSet { get; set; }

        public DateTime Created { get; set; }
        public DateTime LastUpdate { get; set; }

    }
}
