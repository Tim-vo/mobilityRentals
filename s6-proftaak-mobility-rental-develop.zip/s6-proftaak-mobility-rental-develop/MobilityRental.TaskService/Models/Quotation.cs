﻿namespace MobilityRental.AssignmentService.Models
{
    public class Quotation
    {
        public bool Accepted { get; set; }
        public decimal Price { get; set; }
    }
}
