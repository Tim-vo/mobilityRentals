﻿using MobilityRental.AssignmentService.Enums;
using MobilityRental.AssignmentService.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MobilityRental.AssignmentService.Models
{
    public class Assignment
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string Id { get; set; }
        public AssignmentState State { get; set; }
        public AssignmentType Type { get; set; }
        public AssignmentCompletionType CompletionType { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string AssignedAccount { get; set; }
        public string ReportingAccount { get; set; }

        public List<SubAssignment> SubAssignments { get; set; }

        public string OrderNumber { get; set; }
        public OrderInformation OrderInformationSet { get; set; }

        public DateTime Created { get; set; }
        public DateTime LastUpdate { get; set; }
        public List<AssignmentUpdate> Updates { get; set; }
        public string Numberplate { get; set; }
        public bool PermissionGranted { get; set; }

        public bool HasCompleted()
        {
            switch (CompletionType)
            {
                case AssignmentCompletionType.ALL:
                    return this.AllAccepted();
                case AssignmentCompletionType.ONE:
                    var data = this.HasOneAccepted();
                    if (data != null)
                    {
                        return true;
                    }
                    return false;
                case AssignmentCompletionType.NONE:
                    return true;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }
}
