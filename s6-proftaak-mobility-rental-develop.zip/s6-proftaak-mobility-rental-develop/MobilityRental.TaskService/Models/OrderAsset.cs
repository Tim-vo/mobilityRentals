﻿using MobilityRental.Common.Models;

namespace MobilityRental.AssignmentService.Models
{
    public class OrderAsset
    {
        public string Id { get; set; }
        public Order GetOrder { get; set; }
        public Asset GetAsset { get; set; }
    }
}
