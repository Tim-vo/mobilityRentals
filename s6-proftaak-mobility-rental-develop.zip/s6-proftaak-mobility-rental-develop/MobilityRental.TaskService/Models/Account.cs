﻿namespace MobilityRental.AssignmentService.Models
{
    public class Account
    {
        public string Id { get; set; }
    }
}
