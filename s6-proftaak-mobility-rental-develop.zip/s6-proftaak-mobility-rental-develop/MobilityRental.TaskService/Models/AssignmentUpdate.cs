﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MobilityRental.AssignmentService.Models
{
    public class AssignmentUpdate
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string Id { get; set; }
        public string Updater { get; set; }
        public string Description { get; set; }

        public string NewReporter { get; set; }
        public string OldReporter { get; set; }
        public string NewAssigned { get; set; }
        public string OldAssigned { get; set; }

        public DateTime Created { get; set; }
    }
}
