﻿using IntegrationService.Contexts;
using IntegrationService.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace IntegrationService.Logic
{
    public class IntegrationContextLogic
    {
        #region Fields
        private IntegrationContext context;
        #endregion

        #region Setup
        public IntegrationContextLogic(IntegrationContext context)
        {
            this.context = context;
        }
        #endregion

        #region Public
        public async Task<Partner> GetPartner(string accessToken)
        {
            return await this.context.Partner.Where(p => p.AccessToken.Equals(accessToken)).FirstOrDefaultAsync();
        }

        public async Task<Partner[]> GetPartners()
        {
            return await this.context.Partner.ToArrayAsync();
        }
        #endregion
    }
}
