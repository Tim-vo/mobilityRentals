﻿using IntegrationService.Models;
using IntegrationService.Models.Provided;
using IntegrationService.Models.Submitted;
using System;

namespace IntegrationService.Logic
{
    public class Converter
    {
        public Asset ConvertToAsset(Offer submittedAsset, Partner partner)
        {
            return new Asset()
            {
                Name = $"{submittedAsset.Model.Brand} {submittedAsset.Model.Type}",
                PhotoUrl = $"http://mobilityrental.tech/assets/img/{submittedAsset.Model.Category}/{submittedAsset.Model.Type}.jpg",
                Price = Convert.ToDouble(submittedAsset.Price),
                Description = "",
                Brand = new Brand()
                {
                    Name = submittedAsset.Model.Brand
                },
                Type = new Models.Provided.Type()
                {
                    Name = ConvertType(submittedAsset.Model.Category)
                },
                PartnerId = partner.Guid,
                PartnerAssetId = submittedAsset.Id,
                PartnerReferralLink = $"{partner.ReferralLink}{submittedAsset.Id}"
            };
        }

        private string ConvertType(string submittedType)
        {
            switch (submittedType)
            {
                case "Auto":
                    return "Passenger vehicle";
                case "E-bike":
                    return "Bicycle";
                case "Vrachtwagen":
                    return "BigTruck";
                case "Schip":
                    return "Boat";
                default:
                    return "Unknown";
            }
        }
    }
}
