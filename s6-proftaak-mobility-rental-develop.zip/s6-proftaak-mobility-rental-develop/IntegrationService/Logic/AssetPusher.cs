﻿using IntegrationService.Models;
using IntegrationService.Models.Provided;
using Microsoft.Extensions.Logging;
using System.IO;
using System.Net;
using System.Text;
using System.Text.Json;

namespace IntegrationService.Logic
{
    public class AssetPusher
    {
        private IntegrationContextLogic integrationContextLogic;
        private readonly ILogger<AssetPusher> logger;

        public AssetPusher(IntegrationContextLogic integrationContextLogic, ILogger<AssetPusher> logger)
        {
            this.integrationContextLogic = integrationContextLogic;
            this.logger = logger;
        }

        public void Push(Asset asset, string method)
        {
            string json = JsonSerializer.Serialize(asset);
            byte[] body = Encoding.UTF8.GetBytes(json);
            Partner[] partners = integrationContextLogic.GetPartners().Result;

            foreach (Partner partner in partners)
            {
                if (partner.PushEndpoint != null)
                {
                    HttpWebRequest request = CreateHttpRequest(body, partner.PushEndpoint, partner.ExternalAccessToken, method);
                    Transmit(request, body);
                    try
                    {
                        ReadResponse((HttpWebResponse)request.GetResponse());
                    }
                    catch (WebException webException)
                    {
                        logger.LogError($"Transmission went wrong with partner: {partner.Guid}. Exception message: {webException.Message}.");
                        logger.LogError(JsonSerializer.Serialize(webException));
                    }
                }
            }
        }

        private HttpWebRequest CreateHttpRequest(byte[] body, string url, string accessToken, string method)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Headers.Add("Authorization", $"Token {accessToken}");
            request.Method = method;
            request.ContentLength = body.Length;
            request.ContentType = "application/json";
            return request;
        }

        private void Transmit(HttpWebRequest request, byte[] body)
        {
            using (Stream stream = request.GetRequestStream())
            {
                stream.Write(body, 0, body.Length);
                stream.Close();
            }
        }

        private void ReadResponse(HttpWebResponse response)
        {

        }
    }
}
