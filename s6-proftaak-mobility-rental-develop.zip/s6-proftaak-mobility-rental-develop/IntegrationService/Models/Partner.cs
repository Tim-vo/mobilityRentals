﻿using System;

namespace IntegrationService.Models
{
    public partial class Partner
    {
        public Guid Guid { get; set; }
        public string Name { get; set; }
        public string AccessToken { get; set; }
        public string ReferralLink { get; set; }
        public string PushEndpoint { get; set; }
        public string ExternalAccessToken { get; set; }
    }
}
