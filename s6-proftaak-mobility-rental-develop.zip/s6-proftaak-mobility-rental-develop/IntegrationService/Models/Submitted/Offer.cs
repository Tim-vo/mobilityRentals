﻿namespace IntegrationService.Models.Submitted
{
    public class Offer
    {
        public int Id { get; set; }
        public decimal Price { get; set; }
        public Model Model { get; set; }
    }
}
