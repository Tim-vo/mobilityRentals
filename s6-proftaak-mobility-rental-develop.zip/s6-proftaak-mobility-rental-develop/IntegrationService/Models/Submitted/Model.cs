﻿namespace IntegrationService.Models.Submitted
{
    public class Model
    {
        public string Brand { get; set; }
        public string Type { get; set; }
        public string Category { get; set; }
    }
}
