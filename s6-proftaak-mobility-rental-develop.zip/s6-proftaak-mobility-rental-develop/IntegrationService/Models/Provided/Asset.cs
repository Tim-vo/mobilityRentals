﻿using System;

namespace IntegrationService.Models.Provided
{
    public class Asset
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string PhotoUrl { get; set; }
        public double Price { get; set; }
        public string Description { get; set; }
        public Brand Brand { get; set; }
        public Type Type { get; set; }
        public Guid PartnerId { get; set; }
        public int PartnerAssetId { get; set; }
        public string PartnerReferralLink { get; set; }
    }
}
