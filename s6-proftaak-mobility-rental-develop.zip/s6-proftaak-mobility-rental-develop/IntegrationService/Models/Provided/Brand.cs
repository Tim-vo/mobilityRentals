﻿namespace IntegrationService.Models.Provided
{
    public class Brand
    {
        public string Name { get; set; }
    }
}
