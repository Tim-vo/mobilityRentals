﻿namespace IntegrationService.Models.Provided
{
    public class Type
    {
        public string Name { get; set; }
    }
}
