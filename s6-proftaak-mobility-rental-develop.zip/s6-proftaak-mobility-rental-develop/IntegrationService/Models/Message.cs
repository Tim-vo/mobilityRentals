﻿using IntegrationService.Models.Provided;
using MobilityRental.Common.Enums;

namespace IntegrationService.Models
{
    public class Message
    {
        public AssetActionType AssetActionType { get; set; }
        public Asset Asset { get; set; }

        public Message() { }
        public Message(AssetActionType assetActionType, Asset asset)
        {
            AssetActionType = assetActionType;
            Asset = asset;
        }
    }
}
