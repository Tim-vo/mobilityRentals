﻿using IntegrationService.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using MobilityRental.Common.Configuration;

namespace IntegrationService.Contexts
{
    public partial class IntegrationContext : DbContext
    {
        private SQLSettings sqlSettings;

        public IntegrationContext(IOptions<SQLSettings> sqlSettings)
        {
            this.sqlSettings = sqlSettings.Value;
        }

        public IntegrationContext(IOptions<SQLSettings> sqlSettings, DbContextOptions<IntegrationContext> options)
            : base(options)
        {
            this.sqlSettings = sqlSettings.Value;
        }

        public virtual DbSet<Partner> Partner { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(sqlSettings.ConnectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Partner>(entity =>
            {
                entity.HasKey(e => e.Guid)
                    .HasName("PK_Company");

                entity.Property(e => e.Guid).ValueGeneratedNever();

                entity.Property(e => e.AccessToken).IsRequired();

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.ReferralLink).IsRequired();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
