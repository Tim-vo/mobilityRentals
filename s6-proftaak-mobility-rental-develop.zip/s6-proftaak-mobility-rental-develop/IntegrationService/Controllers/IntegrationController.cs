﻿using IntegrationService.Logic;
using IntegrationService.Messaging;
using IntegrationService.Models;
using IntegrationService.Models.Provided;
using IntegrationService.Models.Submitted;
using Microsoft.AspNetCore.Mvc;
using MobilityRental.Common.Enums;
using System.Net;
using System.Threading.Tasks;

namespace IntegrationService
{
    [Route("[controller]/submit")]
    [ApiController]
    public class IntegrationController : Controller
    {
        #region Fields
        private IntegrationContextLogic integrationContextLogic;
        private Converter converter;
        private PartnerAssetEmitMessage partnerAssetEmitMessage;
        #endregion

        #region Setup
        public IntegrationController(IntegrationContextLogic integrationContextLogic, PartnerAssetEmitMessage partnerAssetEmitMessage)
        {
            this.integrationContextLogic = integrationContextLogic;
            this.partnerAssetEmitMessage = partnerAssetEmitMessage;
            converter = new Converter();
        }
        #endregion

        [HttpPost]
        public async Task<ActionResult> SubmitAsset([FromHeader] string authorization, [FromBody] Offer submittedAsset)
        {
            Partner partner = await integrationContextLogic.GetPartner(authorization.Replace("Token ", ""));
            if (partner != null)
            {
                Asset asset = converter.ConvertToAsset(submittedAsset, partner);

                Message message = new Message(AssetActionType.Create, asset);
                partnerAssetEmitMessage.CreateMessage(message);

                return StatusCode((int)HttpStatusCode.OK);
            }
            else
                return StatusCode((int)HttpStatusCode.Unauthorized);

        }

        [HttpPut]
        public async Task<ActionResult> UpdateAsset([FromHeader] string authorization, [FromBody] Offer submittedAsset)
        {
            Partner partner = await integrationContextLogic.GetPartner(authorization.Replace("Token ", ""));
            if (partner != null)
            {
                Asset asset = converter.ConvertToAsset(submittedAsset, partner);

                Message message = new Message(AssetActionType.Update, asset);
                partnerAssetEmitMessage.CreateMessage(message);

                return StatusCode((int)HttpStatusCode.OK);
            }
            else
                return StatusCode((int)HttpStatusCode.Unauthorized);

        }

        [HttpDelete]
        public async Task<ActionResult> DeleteAsset([FromHeader] string authorization, [FromBody] Offer submittedAsset)
        {
            Partner partner = await integrationContextLogic.GetPartner(authorization.Replace("Token ", ""));
            if (partner != null)
            {
                Asset asset = converter.ConvertToAsset(submittedAsset, partner);

                Message message = new Message(AssetActionType.Delete, asset);
                partnerAssetEmitMessage.CreateMessage(message);

                return StatusCode((int)HttpStatusCode.OK);
            }
            else
                return StatusCode((int)HttpStatusCode.Unauthorized);

        }
    }
}
