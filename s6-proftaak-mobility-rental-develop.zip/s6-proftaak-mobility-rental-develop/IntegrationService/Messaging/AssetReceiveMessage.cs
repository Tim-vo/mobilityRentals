﻿using IntegrationService.Logic;
using IntegrationService.Models;
using Microsoft.Extensions.Options;
using MobilityRental.Common.Enums;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Text.Json;

namespace IntegrationService.Messaging
{
    public class AssetReceiveMessage
    {
        private readonly AssetPusher assetPusher;
        private MessageSettings messageSettings;
        private ConnectionFactory factory;
        private IConnection connection;
        private IModel channel;
        private string queueName;
        private EventingBasicConsumer consumer;

        public AssetReceiveMessage(IOptions<MessageSettings> messageSettings, AssetPusher assetPusher)
        {
            this.messageSettings = messageSettings.Value;
            this.factory = new ConnectionFactory() { HostName = this.messageSettings.HostName };
            this.connection = this.factory.CreateConnection();
            this.channel = this.connection.CreateModel();
            this.assetPusher = assetPusher;
        }

        public void StartMessageReceiver()
        {
            channel.ExchangeDeclare(exchange: this.messageSettings.AssetChannel, type: ExchangeType.Fanout);

            this.queueName = channel.QueueDeclare().QueueName;
            this.channel.QueueBind(queue: this.queueName,
                exchange: this.messageSettings.AssetChannel,
                routingKey: "");

            this.consumer = new EventingBasicConsumer(this.channel);
            this.consumer.Received += this.ReceiveMessage;
            this.channel.BasicConsume(queue: this.queueName,
                    autoAck: false,
                    consumer: this.consumer);
        }
        private void ReceiveMessage(object sender, BasicDeliverEventArgs e)
        {
            var body = e.Body;
            var messageJson = Encoding.UTF8.GetString(body.ToArray());
            Message orderAsset = JsonSerializer.Deserialize(messageJson, typeof(Message)) as Message;

            if (orderAsset.AssetActionType == AssetActionType.Create)
                assetPusher.Push(orderAsset.Asset, "POST");
            else if (orderAsset.AssetActionType == AssetActionType.Update)
                Console.Write("Asset updated.");
            else if (orderAsset.AssetActionType == AssetActionType.Delete)
                Console.Write("Asset deleted.");

            this.channel.BasicAck(e.DeliveryTag, false);
        }
    }
}
