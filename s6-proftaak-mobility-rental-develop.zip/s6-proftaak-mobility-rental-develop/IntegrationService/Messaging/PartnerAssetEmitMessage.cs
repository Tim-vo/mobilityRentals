﻿using IntegrationService.Models;
using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using System.Text;
using System.Text.Json;

namespace IntegrationService.Messaging
{
    public class PartnerAssetEmitMessage
    {
        private MessageSettings messageSettings;

        public PartnerAssetEmitMessage(IOptions<MessageSettings> messageSettings)
        {
            this.messageSettings = messageSettings.Value;
        }

        public void CreateMessage(Message message)
        {
            var factory = new ConnectionFactory() { HostName = this.messageSettings.HostName };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: this.messageSettings.PartnerAssetChannel, type: ExchangeType.Fanout);

                var body = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(message));
                channel.BasicPublish(exchange: this.messageSettings.PartnerAssetChannel,
                    routingKey: "",
                    basicProperties: null,
                    body: body);
            }
        }
    }
}
