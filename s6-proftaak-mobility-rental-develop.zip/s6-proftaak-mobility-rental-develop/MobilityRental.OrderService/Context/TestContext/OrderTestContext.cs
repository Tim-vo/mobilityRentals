﻿using MobilityRental.Common.Enums;
using MobilityRental.Common.Models;
using MobilityRental.OrderService.Interfaces;
using System;
using System.Collections.Generic;

namespace MobilityRental.OrderService.Context.TestContext
{
    public class OrderTestContext : IOrderContext
    {
        #region Fields
        private readonly List<Order> _orders;
        #endregion

        #region Setup
        public OrderTestContext()
        {
            var assets = new List<Asset>()
            {
                new Asset()
                {
                    Id = 1,
                    Name = "Peugeot 307",
                    Description = "A nice car",
                    PhotoUrl = "test",
                    Price = 234,
                    SerialNumber = "S12345",
                    Type = new Common.Models.Type {Id = 1}
                },

                new Asset()
                {
                    Id = 2,
                    Name = "Peugeot 308",
                    Description = "A nicer car",
                    PhotoUrl = "test",
                    Price = 334,
                    SerialNumber = "S22345",
                    Type = new Common.Models.Type {Id = 1}
                }
            };

            _orders = new List<Order>()
            {
                new Order()
                {
                    Id = "RandomString1",
                    Number = "000001",
                    OrderDate = DateTime.Now,
                    StartDate = new DateTime(2020, 05, 22),
                    EndDate = new DateTime(2020, 05, 22),
                    State = 0,
                    AssetId = assets[0].Id,
                    Deliver = true
                },

                new Order()
                {
                    Id = "RandomString2",
                    Number = "000002",
                    OrderDate = DateTime.Now,
                    StartDate = new DateTime(2020, 06, 18),
                    EndDate = new DateTime(2020, 06, 18),
                    State = 0,
                    AssetId = assets[1].Id,
                    Deliver = true
                },

                new Order()
                {
                    Id = "RandomString3",
                    Number = "000003",
                    OrderDate = DateTime.Now,
                    StartDate = new DateTime(2020, 12, 18),
                    EndDate = new DateTime(2020, 12, 18),
                    State = OrderState.PendingOrder,
                    AssetId = assets[0].Id,
                    Deliver = false
                },
            };
        }
        #endregion

        #region Methods
        public Order CreateOrder(Order order)
        {
            var id = "randomid";

            this._orders.Add(new Order()
            {
                Id = id,
                AccountId = order.AccountId,
                AssetId = order.AssetId,
                OrderDate = DateTime.Now,
                StartDate = order.StartDate,
                EndDate = order.EndDate,
                Number = DateTime.Now.ToString("yyyyMMMddhhmmssfff"),
                State = order.State,
                Deliver = order.Deliver,
                Accessories = order.Accessories
            });

            return _orders[1];
        }

        public List<Order> GetAccountOrders(string accountId)
        {
            throw new NotImplementedException();
        }

        public Order GetOrder(string id)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
