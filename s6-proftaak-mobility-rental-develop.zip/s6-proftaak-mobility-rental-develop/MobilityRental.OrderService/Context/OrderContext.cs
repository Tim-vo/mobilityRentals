﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MobilityRental.Common.Configuration;
using MobilityRental.Common.Interfaces;
using MobilityRental.Common.Models;
using MobilityRental.OrderService.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MobilityRental.OrderService.Context
{
    public class OrderContext : DbContext, IOrderContext
    {
        private TranslationSettings _settings;
        private IOptions<SQLSettings> _sqlSettings;
        public DbSet<Order> Orders { get; set; }

        #region Constructors
        public OrderContext(IOptions<SQLSettings> _SqlSettings, ILogger<ISqlDbContext> logger, IOptions<TranslationSettings> transSettings)
        {
            _settings = transSettings.Value;
            _sqlSettings = _SqlSettings;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_sqlSettings.Value.ConnectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("Order");
        }
        #endregion

        #region Methods
        public Order CreateOrder(Order order)
        {
            order.Id = null;
            order.Number = DateTime.Now.ToString("yyyyMMddHHmmssfffffff");
            order.PersonalInformation.Id = null;
            order.OrderDate = DateTime.Now;
            Add(order);
            SaveChanges();
            return order;
        }

        public Order GetOrder(string id)
        {
            var result = Orders.Where(a => a.Id == id).Include(item => item.PersonalInformation);
            Order order = null;
            if (result.Any())
            {
                order = result.First();
            }
            return order;
        }

        public List<Order> GetAccountOrders(string accountId)
        {
            var results = Orders.Where(O => O.AccountId == accountId).Include(O => O.PersonalInformation);

            return results.ToList();
        }

        #endregion


    }
}
