﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MobilityRental.Common.Extensions;
using MobilityRental.Common.Models;
using MobilityRental.Common.Translation;
using MobilityRental.OrderService.Interfaces;
using MobilityRental.OrderService.Message;
using MobilityRental.OrderService.Model;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace MobilityRental.OrderService.Controllers
{
    [ApiController]
    [Authorize]
    [Route("[controller]")]
    public class OrderController : Controller
    {
        #region Fields
        private readonly IOrderContext _orderContext;
        private readonly OrderEmitMessage orderEmitMessage;
        private readonly ILogger<OrderController> _logger;
        private readonly TranslationService _translationService;

        #endregion

        #region Setup
        public OrderController(IOrderContext orderContext, OrderEmitMessage orderEmitMessage, ILogger<OrderController> logger, TranslationService translationService)
        {
            _orderContext = orderContext;
            this.orderEmitMessage = orderEmitMessage;
            _logger = logger;
            _translationService = translationService;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Add an order to the database
        /// </summary>
        /// <param name="order">Order information</param>
        [HttpPost]
        public async Task<Order> AddOrder(OrderAsset orderAsset)
        {
            _logger?.LogInformation("Creating order for {{account}} for asset {{asset}}", orderAsset.GetOrder.AccountId, orderAsset.GetAsset.Id);
            string lang = HttpContext?.GetLanguage();

            orderAsset.GetOrder.AccountId = User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            Order orderReturn = _orderContext.CreateOrder(orderAsset.GetOrder);
            if (orderReturn != null)
            {
                orderAsset.GetOrder = orderReturn;
                orderEmitMessage?.CreateMessage(orderAsset);
                if (_translationService != null)
                {
                    await _translationService.GetTranslation(orderEmitMessage, HttpContext?.GetLanguage());
                }

                return orderReturn;
            }

            return null;
        }

        /// <summary>
        /// Retreive an accounts orders based on the JWT token
        /// </summary>
        /// <returns></returns>
        [HttpGet("account")]
        public List<Order> GetAccountOrders()
        {
            _logger.LogInformation("Request orders for {account} ", User.GetUserId());
            return _orderContext.GetAccountOrders(User.GetUserId());
        }

        /// <summary>
        /// Retrieve an specific order
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        [HttpGet("{id}")]
        public async Task<Order> GetOrder(string id)
        {
            _logger.LogInformation("Retrieving order {id}", id);
            Order order = _orderContext.GetOrder(id);

            if (order != null && order.AccountId == User.GetUserId())
            {
                await _translationService.GetTranslation(order, HttpContext.GetLanguage());
                return order;
            }

            return null;
        }
        #endregion
    }
}