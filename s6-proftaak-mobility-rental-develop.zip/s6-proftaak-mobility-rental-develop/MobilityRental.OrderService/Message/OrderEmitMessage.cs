﻿using Microsoft.Extensions.Options;
using MobilityRental.Common.Configuration;
using MobilityRental.OrderService.Model;
using RabbitMQ.Client;
using System.Text;
using System.Text.Json;

namespace MobilityRental.OrderService.Message
{
    public class OrderEmitMessage
    {
        private MessageSettings messageSettings;

        public OrderEmitMessage(IOptions<MessageSettings> messageSettings)
        {
            this.messageSettings = messageSettings.Value;
        }

        public void CreateMessage(OrderAsset orderAsset)
        {
            var factory = new ConnectionFactory() { HostName = this.messageSettings.HostName };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: this.messageSettings.Channel, type: ExchangeType.Fanout);

                var body = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(orderAsset));
                channel.BasicPublish(exchange: this.messageSettings.Channel,
                    routingKey: "",
                    basicProperties: null,
                    body: body);
            }
        }
    }
}
