﻿using MobilityRental.Common.Models;

namespace MobilityRental.OrderService.Model
{
    public class OrderAsset
    {
        public Order GetOrder { get; set; }
        public Asset GetAsset { get; set; }
    }
}
