﻿using MobilityRental.Common.Models;
using System.Collections.Generic;

namespace MobilityRental.OrderService.Interfaces
{
    public interface IOrderContext
    {
        Order CreateOrder(Order order);

        Order GetOrder(string id);
        List<Order> GetAccountOrders(string accountId);
    }
}
