﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MobilityRental.AccountService.Models;
using MobilityRental.Common.Configuration;
using MobilityRental.Common.Interfaces;

namespace MobilityRental.AccountService.Context
{
    public class IdentityContext : IdentityDbContext<Account, Role, string>
    {
        private readonly string _connectionString;
        private ILogger<ISqlDbContext> _logger;

        public IdentityContext(IOptions<SQLSettings> sqlSettings, ILogger<ISqlDbContext> logger)
        {
            _logger = logger;
            _connectionString = sqlSettings.Value.ConnectionString;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_connectionString);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.HasDefaultSchema("Account");

            builder.Entity<Role>().HasData(
                new Role
                {
                    Name = "Administrator",
                    Description = "A full administrator to this applications, has access to everything."
                },
                new Role
                {
                    Name = "RoleAdministrator",
                    Description = "A administrative role that can manage roles and add them to users"
                });

            base.OnModelCreating(builder);
        }
    }
}
