﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MobilityRental.AccountService.Messaging;
using MobilityRental.Common.Configuration;
using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;

namespace MobilityRental.AccountService.Context
{
    public class MessageBrokerContext
    {
        private readonly ILogger<MessageBrokerContext> _logger;
        private IConnection _savedConnection;
        private IConnection _connection => GetConnection();
        private readonly ConnectionFactory _factory;
        private readonly MessageSettings _brokerSettings;
        private MessageHandler _handler;

        public MessageBrokerContext(ILogger<MessageBrokerContext> logger, IOptions<MessageSettings> brokerSettings, MessageHandler handler)
        {
            _logger = logger;
            _handler = handler;
            _brokerSettings = brokerSettings.Value;
            _factory = new ConnectionFactory() { HostName = _brokerSettings.HostName, UserName = _brokerSettings.Username, Password = _brokerSettings.Password };
            //ReceiveMessages(_brokerSettings.Channel);
        }

        public IConnection GetConnection()
        {
            if (_savedConnection != null && _savedConnection.IsOpen)
            {
                return _savedConnection;
            }
            _logger.LogWarning("Creating a new connection to the Content broker");
            _savedConnection = _factory.CreateConnection();
            return _savedConnection;
        }

        private void ReceiveMessages(string exchange)
        {
            var channel = GetConnection().CreateModel();

            channel.ExchangeDeclare(exchange: exchange, type: ExchangeType.Fanout);

            var queueName = channel.QueueDeclare().QueueName;
            channel.QueueBind(queue: queueName,
                exchange: exchange,
                routingKey: "");

            _logger.LogInformation("Starting to listen to exchange: {ex}", exchange);

            var consumer = new EventingBasicConsumer(channel);
            consumer.Received += (model, eventargs) =>
            {
                var body = eventargs.Body;
                var message = Encoding.UTF8.GetString(body.ToArray());
                _logger.LogDebug("Message received from exchange");
                _handler.HandleMessage(this, message);
            };
            channel.BasicConsume(queue: queueName,
                autoAck: true,
                consumer: consumer);
        }


        /// <summary>
        /// Send a Content to the Content broker
        /// </summary>
        /// <param Name="exchange">The exchange/queue you want to throw the Content into</param>
        /// <param Name="data">The object that has to be converted to JSON and sent to the queue</param>
        public void CreateMessage(string exchange, object data)
        {
            using (var channel = _connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: exchange, type: ExchangeType.Fanout);

                var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(data));
                channel.BasicPublish(exchange: exchange,
                    routingKey: "",
                    basicProperties: null,
                    body: body);
                _logger.LogDebug("Sending Content to exchange {exchange}", exchange, body);
            }
        }
    }
}
