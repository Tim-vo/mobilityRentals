﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MobilityRental.AccountService.Logic;
using MobilityRental.AccountService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace MobilityRental.AccountService.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly SignInManager<Account> _signInManager;
        private readonly UserManager<Account> _userManager;
        private readonly AccountLogic _accountLogic;

        public AccountController(
            UserManager<Account> userManager,
            SignInManager<Account> signInManager,
            AccountLogic accountLogic)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _accountLogic = accountLogic;
        }

        /// <summary>
        /// Allow to login
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Filtered user model with a JWT token</returns>
        [HttpPost("login")]
        public async Task<Object> Login(LoginDto model)
        {
            var result = await _signInManager.PasswordSignInAsync(model.Email, model.Password, false, false);

            if (result.Succeeded)
            {
                var appUser = _userManager.Users.SingleOrDefault(r => r.NormalizedEmail == model.Email.ToUpper());
                LoginDto login = new LoginDto
                {
                    Email = model.Email,
                    Token = await _accountLogic.GenerateJWTToken(appUser)
                };
                return login;
            }

            return Unauthorized();
        }

        /// <summary>
        /// Register and login the user
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Filtered user model with a JWT token</returns>
        [HttpPost, Route("register")]
        public async Task<LoginDto> Register(RegisterDto model)
        {
            var user = new Account
            {
                Email = model.Email,
                UserName = model.Email,
                CreationDate = DateTime.Now,
                FirstName = model.FirstName,
                LastName = model.LastName
            };
            var result = await _userManager.CreateAsync(user, model.Password);

            if (result.Succeeded)
            {
                await _signInManager.SignInAsync(user, false);
                LoginDto login = new LoginDto()
                {
                    Email = user.Email,
                    Token = await _accountLogic.GenerateJWTToken(user)
                };
                return login;
            }

            throw new ApplicationException("UNKNOWN_ERROR");
        }

        /// <summary>
        /// Change the user email
        /// </summary>
        /// <param name="newEmail"></param>
        /// <returns></returns>
        [Authorize]
        [HttpPut("email")]
        public async Task<string> ChangeEmail(string newEmail)
        {
            var id = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var currentUser = await _userManager.FindByIdAsync(id);
            currentUser.Email = newEmail;
            await _userManager.UpdateAsync(currentUser); //For the whole user you can just call updateasync
            return "Success";
        }

        /// <summary>
        /// Get user based on the jwt token
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpGet]
        public async Task<Account> GetUser()
        {
            var id = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            var currentUser = await _userManager.FindByIdAsync(id);
            if (currentUser != null)
            {
#warning move to [jsonignore]
                currentUser.PasswordHash = null;
                currentUser.SecurityStamp = null;

            }

            return currentUser;
        }
        
        /// <summary>
        /// Get accounts that have this role attached
        /// </summary>
        /// <param name="role"></param>
        /// <returns></returns>
        [Authorize(Roles = "Administrator, RoleAdministrator")]
        [HttpPost("role")]
        public List<Account> GetRolesOnAccount(Role role)
        {
            return _accountLogic.GetAccounts(role);
        }
    }
}