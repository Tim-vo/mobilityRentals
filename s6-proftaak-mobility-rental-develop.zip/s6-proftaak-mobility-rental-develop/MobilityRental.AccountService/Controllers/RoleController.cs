﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MobilityRental.AccountService.Models;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace MobilityRental.AccountService.Controllers
{
    [Authorize]
    [Route("[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly UserManager<Account> _userManager;
        private readonly RoleManager<Role> _roleManager;

        public RoleController(UserManager<Account> userManager, RoleManager<Role> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }

        /// <summary>
        /// Add a role to the specific user
        /// </summary>
        /// <param name="roleName"></param>
        /// <returns>If it has completed successfully, a new JWT token has to be generated for the authorization to fully work</returns>
        [Authorize(Roles = "Administrator, RoleAdministrator")]
        [HttpPost, Route("add")]
        public async Task<string> AddRoleToUser(string userid, string roleName)
        {
            var currentUser = await _userManager.FindByIdAsync(userid);

            var roleresult = await _userManager.AddToRoleAsync(currentUser, roleName);
            return roleresult.ToString();

        }

        /// <summary>
        /// Create a role with this specific name
        /// </summary>
        /// <param name="roleName"></param>
        /// <returns></returns>
        [Authorize(Roles = "Administrator, RoleAdministrator")]
        [HttpPost]
        public async Task<Role> CreateRole(Role role)
        {
            if (!(await _roleManager.RoleExistsAsync(role.Name)))
            {
                await _roleManager.CreateAsync(role);
                return role;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Get the current user roles
        /// </summary>
        /// <returns>A list of the role names</returns>
        [HttpGet("current/all")]
        public async Task<List<Role>> GetAllUserRoles()
        {
            List<Role> result = new List<Role>();
            var id = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var currentUser = await _userManager.FindByIdAsync(id);
            var roleList = await _userManager.GetRolesAsync(currentUser);
            foreach (var role in roleList)
            {
                Role foundRole = await _roleManager.FindByNameAsync(role.ToUpper());
                result.Add(foundRole);

            }
            return result;
        }

        /// <summary>
        /// Get all roles in the database
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "Administrator, RoleAdministrator")]
        [HttpGet("all")]
        public async Task<List<Role>> GetAllRoles()
        {
            var roleList = _roleManager.Roles.ToList();
            return roleList;
        }
    }
}