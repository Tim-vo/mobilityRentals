﻿using Microsoft.AspNetCore.Identity;

namespace MobilityRental.AccountService.Models
{
    public class Role : IdentityRole
    {
        public string Description { get; set; }

    }
}
