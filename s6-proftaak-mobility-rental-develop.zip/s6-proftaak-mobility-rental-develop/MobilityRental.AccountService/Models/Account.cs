﻿using Microsoft.AspNetCore.Identity;
using System;

namespace MobilityRental.AccountService.Models
{
    public class Account : IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public DateTime CreationDate { get; set; }
    }
}
