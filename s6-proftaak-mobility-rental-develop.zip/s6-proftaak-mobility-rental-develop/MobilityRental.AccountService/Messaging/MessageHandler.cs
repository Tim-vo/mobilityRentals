﻿using Microsoft.Extensions.Options;
using MobilityRental.AccountService.Context;
using MobilityRental.AccountService.Logic;
using MobilityRental.AccountService.Models;
using MobilityRental.Common.Configuration;
using MobilityRental.Common.Enums;
using MobilityRental.Common.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;

namespace MobilityRental.AccountService.Messaging
{
    public class MessageHandler
    {
        private MessageSettings _messageSettings;
        private AccountLogic _accountLogic;

        public MessageHandler(IOptions<MessageSettings> messageSettings, AccountLogic accountLogic)
        {
            _accountLogic = accountLogic;
            _messageSettings = messageSettings.Value;
        }

        /// <summary>
        /// Handle the incoming message from an exchange
        /// </summary>
        /// <param name="message">The message in json that will be handled</param>
        public void HandleMessage(MessageBrokerContext brokerContext, string message)
        {
            var item = JsonConvert.DeserializeObject<AccountMessage>(message);
            switch (item.Method)
            {
                case AccountMethod.GETALLUSERSONROLE:
                    Role role = ((JObject)item.Data).ToObject<Role>();
                    var data = _accountLogic.GetAccounts(role);
                    //brokerContext.CreateMessage(item.Origin, data);
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }
}
