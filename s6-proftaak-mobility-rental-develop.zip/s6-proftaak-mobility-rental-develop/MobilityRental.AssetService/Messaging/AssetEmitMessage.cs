﻿using Microsoft.Extensions.Options;
using RabbitMQ.Client;
using System.Text;
using System.Text.Json;

namespace MobilityRental.AssetService.Messaging
{
    public class AssetEmitMessage
    {
        private MessageSettings messageSettings;

        public AssetEmitMessage(IOptions<MessageSettings> messageSettings)
        {
            this.messageSettings = messageSettings.Value;
        }

        public void CreateMessage(Message message)
        {
            var factory = new ConnectionFactory() { HostName = this.messageSettings.HostName };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(exchange: this.messageSettings.AssetChannel, type: ExchangeType.Fanout);

                var body = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(message));
                channel.BasicPublish(exchange: this.messageSettings.AssetChannel,
                    routingKey: "",
                    basicProperties: null,
                    body: body);
            }
        }
    }
}
