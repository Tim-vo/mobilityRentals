﻿using Microsoft.Extensions.Options;
using MobilityRental.AssetService.Interfaces;
using MobilityRental.Common.Models;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;
using System.Text.Json;

namespace MobilityRental.AssetService.Messaging
{
    public class PartnerAssetReceiveMessage
    {
        private MessageSettings messageSettings;
        private ConnectionFactory factory;
        private IConnection connection;
        private IModel channel;
        private string queueName;
        private EventingBasicConsumer consumer;
        private IAssetContext assetContext;
        private ITypeContext typeContext;

        public PartnerAssetReceiveMessage(IOptions<MessageSettings> messageSettings, IAssetContext assetContext, ITypeContext typeContext)
        {
            this.messageSettings = messageSettings.Value;
            this.assetContext = assetContext;
            this.typeContext = typeContext;
            this.factory = new ConnectionFactory() { HostName = this.messageSettings.HostName };
            this.connection = this.factory.CreateConnection();
            this.channel = this.connection.CreateModel();
        }

        public void StartMessageReceiver()
        {
            channel.ExchangeDeclare(exchange: this.messageSettings.PartnerAssetChannel, type: ExchangeType.Fanout);

            this.queueName = channel.QueueDeclare().QueueName;
            this.channel.QueueBind(queue: this.queueName,
                exchange: this.messageSettings.PartnerAssetChannel,
                routingKey: "");

            this.consumer = new EventingBasicConsumer(this.channel);
            this.consumer.Received += this.ReceiveMessage;
            this.channel.BasicConsume(queue: this.queueName,
                    autoAck: false,
                    consumer: this.consumer);
        }
        private void ReceiveMessage(object sender, BasicDeliverEventArgs e)
        {
            var body = e.Body;
            var messageJson = Encoding.UTF8.GetString(body.ToArray());
            Message orderAsset = JsonSerializer.Deserialize(messageJson, typeof(Message)) as Message;
            orderAsset.Asset.Available = true;
            orderAsset.Asset.SerialNumber = "";
            orderAsset.Asset.Type = typeContext.GetType(orderAsset.Asset.Type.Name, "en").Result;
            Brand brand = orderAsset.Asset.Brand;
            orderAsset.Asset.Brand = assetContext.GetBrand(brand.Name, "en").Result;
            if (orderAsset.Asset.Brand == null)
                orderAsset.Asset.Brand = assetContext.CreateBrand(brand, "en").Result;

            if (orderAsset.AssetActionType == Common.Enums.AssetActionType.Create)
                assetContext.CreateAsset(orderAsset.Asset, "en");
            else if (orderAsset.AssetActionType == Common.Enums.AssetActionType.Update)
                assetContext.UpdateAsset(orderAsset.Asset, "en");
            else if (orderAsset.AssetActionType == Common.Enums.AssetActionType.Delete)
                assetContext.DeleteAsset(orderAsset.Asset);

            this.channel.BasicAck(e.DeliveryTag, false);
        }
    }
}
