using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MobilityRental.AssetService.Interfaces;
using MobilityRental.AssetService.Messaging;
using MobilityRental.Common.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MobilityRental.AssetService.Controllers
{
    /// <summary>
    /// Responsible for all asset related code.
    /// </summary>
    [Route("[controller]")]
    [ApiController]
    public class AssetController : ControllerBase
    {
        private IAssetContext _assetContext;
        private readonly AssetEmitMessage assetEmitMessage;

        public AssetController(IAssetContext assetContext, AssetEmitMessage assetEmitMessage)
        {
            _assetContext = assetContext;
            this.assetEmitMessage = assetEmitMessage;
        }

        /// <summary>
        /// Retrieve the asset on a ID.
        /// </summary>
        /// <param name="id">ID of the asset</param>
        /// <returns>An asset or a 405 if it can't be found.</returns>
        [HttpGet("{id}")]
        public async Task<Asset> GetAssetAsync(int id)
        {
            string lang = HttpContext?.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            Asset asset = await _assetContext.GetAsset(id, lang);
            asset.Accessories = await GetAccessoriesOfAsset(id);
            asset.Specifications = await GetSpecificationsOfAsset(id);
            return asset;
        }

        /// <summary>
        /// Retrieve a specific page with assets
        /// </summary>
        /// <param name="page">The current page you want to retrieve</param>
        /// <param name="amount">The amount of assets you want to show per page</param>
        /// <param name="filter"></param>
        /// <returns>A page</returns>
        [HttpPost("page")]
        public async Task<List<Asset>> GetPage(Filter filter)
        {
            string lang = HttpContext?.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            return await _assetContext.GetPage(filter, lang);
        }

        /// <summary>
        /// Search all assets on a specific term
        /// </summary>
        /// <param name="term">The term you want to search</param>
        /// <returns>Returns a list of the specific assets</returns>
        [HttpGet("search")]
        public async Task<List<Asset>> SearchAssets(string term)
        {
            string lang = HttpContext?.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            return await _assetContext.SearchAssets(term, lang);
        }

        /// <summary>
        /// Create an asset
        /// </summary>
        /// <param name="asset">The filled asset model</param>
        /// <returns>The created result in from the database</returns>
        [HttpPost]
        [Authorize]
        public async Task<Asset> CreateAsset(Asset asset)
        {
            string lang = HttpContext?.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            Asset result = await _assetContext.CreateAsset(asset, lang);
            if (result.Id > 0)
            {
                Message message = new Message(Common.Enums.AssetActionType.Create, result);
                assetEmitMessage?.CreateMessage(message);
            }

            return result;
        }

        /// <summary>
        /// Update an asset
        /// </summary>
        /// <param name="asset">The asset that has to be updated with all its fields</param>
        /// <returns>The updated asset from the database</returns>
        [HttpPut]
        public async Task<Asset> UpdateAsset(Asset asset)
        {
            string lang = HttpContext?.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            Asset result = await _assetContext.UpdateAsset(asset, lang);
            Message message = new Message(Common.Enums.AssetActionType.Update, result);
            assetEmitMessage?.CreateMessage(message);
            return result;
        }

        /// <summary>
        /// Delete an asset from the database
        /// </summary>
        /// <param name="asset">The asset that has to be deleted</param>
        /// <returns>If it has successfully proceeded or not.</returns>
        [HttpDelete]
        public async Task<bool> DeleteAsset(Asset asset)
        {
            if (await _assetContext.DeleteAsset(asset))
            {
                Message message = new Message(Common.Enums.AssetActionType.Delete, asset);
                assetEmitMessage?.CreateMessage(message);
                return true;
            }

            return false;
        }

        /// <summary>
        /// Gets all the types from the database
        /// </summary>
        /// <param name="getNumberOfAssets">Boolen of the number of assets</param>
        /// <returns>List of all the types</returns>
        [HttpGet("types")]
        public async Task<List<Type>> GetTypes(bool getNumberOfAssets)
        {
            string lang = HttpContext?.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            return await _assetContext.GetTypes(getNumberOfAssets, lang);
        }

        /// <summary>
        /// Gets all the brands from the database
        /// </summary>
        /// <param name="getNumberOfAssets">Boolean of the number of assets</param>
        /// <param name="typeId">The Id of a type</param>
        /// <returns>List of brands</returns>
        [HttpGet("brands")]
        public async Task<List<Brand>> GetBrands(bool getNumberOfAssets, int typeId)
        {
            string lang = HttpContext?.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            return await _assetContext.GetBrands(getNumberOfAssets, typeId, lang);
        }

        /// <summary>
        /// Finds the number of results with certain filters
        /// </summary>
        /// <param name="filter">A set of multiple filters</param>
        /// <returns>The amount of results</returns>
        [HttpGet("numberofresults")]
        public async Task<int> GetTotalNumberOfResults(Filter filter)
        {
            return await _assetContext.GetTotalNumberOfResults(filter);
        }

        /// <summary>
        /// Gets all the accessories of an asset
        /// </summary>
        /// <param name="id">The asset id</param>
        /// <returns>A list of accessories</returns>
        [HttpGet("assetaccesories")]
        public async Task<List<Accessory>> GetAccessoriesOfAsset(int id)
        {
            string lang = HttpContext?.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            return await _assetContext.GetAccessoriesOfAsset(id, lang);
        }

        /// <summary>
        /// Gets all the accessories of a type
        /// </summary>
        /// <param name="typeId">The type id</param>
        /// <returns>A list of accessories</returns>
        [HttpGet("typeaccesories")]
        public async Task<List<Accessory>> GetAccessoriesOfType(int typeId)
        {
            string lang = HttpContext?.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            return await _assetContext.GetAccessoriesOfType(typeId, lang);
        }

        /// <summary>
        /// Gets all the specifiactions of an asset
        /// </summary>
        /// <param name="id">The asset Id</param>
        /// <returns>A list of specifications</returns>
        [HttpGet("assetspecifications")]
        public async Task<List<Specification>> GetSpecificationsOfAsset(int id)
        {
            string lang = HttpContext?.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            return await _assetContext.GetSpecificationsOfAsset(id, lang);
        }

        /// <summary>
        /// Gets all the specifications of a type
        /// </summary>
        /// <param name="typeId">The type id</param>
        /// <returns>A list of specifications</returns>
        [HttpGet("typespecifications")]
        public async Task<List<Specification>> GetSpecificationsOfType(int typeId)
        {
            string lang = HttpContext?.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            return await _assetContext.GetSpecificationsOfType(typeId, lang);
        }
    }
}