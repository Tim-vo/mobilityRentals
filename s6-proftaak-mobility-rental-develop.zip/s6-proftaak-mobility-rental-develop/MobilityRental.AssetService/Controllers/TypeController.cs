﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MobilityRental.AssetService.Interfaces;
using System.Threading.Tasks;
using Type = MobilityRental.Common.Models.Type;

namespace MobilityRental.AssetService.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class TypeController : ControllerBase
    {
        private ITypeContext _typeContext;

        public TypeController(ITypeContext typeContext)
        {
            _typeContext = typeContext;
        }

        /// <summary>
        /// Retrieve type on ID
        /// </summary>
        /// <param name="id">ID of the type</param>
        /// <returns>The type that has the same ID</returns>
        [HttpGet, Route("get/{id}")]
        public async Task<Type> Get(int id)
        {
            string lang = HttpContext.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            return await _typeContext.GetType(id, lang);
        }

        /// <summary>
        /// Create a type
        /// </summary>
        /// <param name="type">Filled model received from the frontend</param>
        /// <returns>The created type model</returns>
        [HttpPost, Route("create")]
        public async Task<Type> Create([FromBody] Type type)
        {
            string lang = HttpContext.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            return await _typeContext.CreateType(type, lang);
        }

        /// <summary>
        /// Update a type
        /// </summary>
        /// <param name="type">Filled model received from the frontend</param>
        /// <returns>The updated type model</returns>
        [HttpPut, Route("update")]
        public async Task<Type> Update([FromBody] Type type)
        {
            string lang = HttpContext.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
            return await _typeContext.UpdateType(type, lang);
        }

        /// <summary>
        /// Delete a type
        /// </summary>
        /// <param name="id">Id of the type to be deleted</param>
        /// <returns>A success or failure message</returns>
        [HttpDelete, Route("delete")]
        public async Task<bool> Delete(int id)
        {
            return await _typeContext.DeleteType(id);
        }
    }
}