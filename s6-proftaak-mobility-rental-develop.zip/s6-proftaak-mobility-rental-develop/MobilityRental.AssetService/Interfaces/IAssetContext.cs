﻿using MobilityRental.Common.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MobilityRental.AssetService.Interfaces
{
    public interface IAssetContext
    {
        Task<Asset> GetAsset(int id, string lang);
        Task<List<Asset>> GetPage(Filter filter, string lang);
        Task<List<Asset>> SearchAssets(string term, string lang);
        Task<Asset> CreateAsset(Asset asset, string lang);
        Task<bool> DeleteAsset(Asset asset);
        Task<Asset> UpdateAsset(Asset asset, string lang);
        Task<List<Type>> GetTypes(bool getNumberOfAssets, string lang);
        Task<Brand> CreateBrand(Brand brand, string lang);
        Task<Brand> GetBrand(string name, string lang);
        Task<List<Brand>> GetBrands(bool getNumberOfAssets, int typeId, string lang);
        Task<int> GetTotalNumberOfResults(Filter filter);
        Task<List<Specification>> GetSpecificationsOfAsset(int id, string lang);
        Task<List<Accessory>> GetAccessoriesOfAsset(int id, string lang);
        Task<List<Specification>> GetSpecificationsOfType(int id, string lang);
        Task<List<Accessory>> GetAccessoriesOfType(int id, string lang);
    }
}
