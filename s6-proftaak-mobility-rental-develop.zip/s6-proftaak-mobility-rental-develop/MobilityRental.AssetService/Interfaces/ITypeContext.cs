﻿using System.Threading.Tasks;
using Type = MobilityRental.Common.Models.Type;

namespace MobilityRental.AssetService.Interfaces
{
    public interface ITypeContext
    {
        Task<Type> GetType(int id, string lang);
        Task<Type> GetType(string name, string lang);
        Task<Type> CreateType(Type type, string lang);
        Task<Type> UpdateType(Type type, string lang);
        Task<bool> DeleteType(int id);
    }
}
