﻿using MobilityRental.AssetService.Interfaces;
using MobilityRental.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MobilityRental.AssetService.Context.TestContext
{
    public class AssetTestContext : IAssetContext
    {
        #region Fields

        private readonly List<Asset> _assets;
        private readonly List<Common.Models.Type> _types;
        private readonly List<Specification> _specifications;
        private readonly List<Accessory> _accessories;
        private readonly List<Brand> _brands;
        #endregion

        #region Setup
        public AssetTestContext()
        {
            _brands = new List<Brand>()
            {
                new Brand()
                {
                    Id = 1,
                    Name = "Peugeot",
                    AssetCount = 0
                },

                new Brand()
                {
                    Id = 2,
                    Name = "Toyota",
                    AssetCount = 0
                }
            };

            _specifications = new List<Specification>()
            {
                new Specification()
                {
                    Id = 1,
                    Name = "Door amount",
                    Value = "4"
                },

                new Specification()
                {
                    Id = 2,
                    Name = "Max Speed",
                    Value = "180 km/h"
                }
            };

            _accessories = new List<Accessory>()
            {
                new Accessory()
                {
                    Id = 1,
                    Name = "Airco"
                },

                new Accessory()
                {
                    Id = 2,
                    Name = "Cruise Control"
                }
            };

            _types = new List<Common.Models.Type>()
            {
                new Common.Models.Type()
                {
                    Id = 1,
                    Name = "Passenger Vehicle",
                    PhotoUrl = "test",
                    AssetCount = 0
                },
                new Common.Models.Type()
                {
                    Id = 2,
                    Name = "Bus",
                    PhotoUrl = "test",
                    AssetCount = 0
                },
                new Common.Models.Type()
                {
                    Id = 3,
                    Name = "Bicycle",
                    PhotoUrl = "test",
                    AssetCount = 0
                }
            };

            _assets = new List<Asset>()
            {
                new Asset()
                {
                    Id = 1,
                    Name = "Peugeot 307",
                    Description = "A nice car",
                    PhotoUrl = "test",
                    Price = 234,
                    SerialNumber = "S12345",
                    Type = _types[0],
                    Available = true,
                    Accessories = _accessories,
                    Specifications = _specifications,
                    Brand = _brands[0]
                },

                new Asset()
                {
                    Id = 2,
                    Name = "Peugeot 308",
                    Description = "A nicer car",
                    PhotoUrl = "test",
                    Price = 334,
                    SerialNumber = "S22345",
                    Type = _types[0],
                    Available = true,
                    Accessories = _accessories,
                    Specifications = _specifications,
                    Brand = _brands[0]
                }
            };
        }
        #endregion

        public Task<Asset> GetAsset(int id, string lang)
        {
            return Task.Run(() => _assets.FirstOrDefault(x => x.Id.Equals(id)));
        }

        public Task<List<Asset>> GetPage(Filter filter, string lang)
        {
            var assets = _assets.FindAll(x => x.Type.Id.Equals(filter.TypeId));
            return Task.Run(() => assets.GetRange(0, filter.Amount));
        }

        public Task<List<Asset>> SearchAssets(string term, string lang)
        {
            return Task.Run(() => _assets.FindAll(x => x.Name.Contains(term)));
        }

        public async Task<Asset> CreateAsset(Asset asset, string lang)
        {
            var id = this._assets[^1].Id + 1;

            this._assets.Add(new Asset()
            {
                Id = id,
                Name = asset.Name,
                Description = asset.Description,
                PhotoUrl = asset.PhotoUrl,
                Price = asset.Price,
                SerialNumber = asset.SerialNumber,
                Type = asset.Type,
                Available = asset.Available
            });

            return await Task.Run(() => _assets[id - 1]);
        }

        public Task<bool> DeleteAsset(Asset asset)
        {
            Asset tempAsset = _assets.FirstOrDefault(x => x.Id.Equals(asset.Id));

            return tempAsset != null ? Task.Run(() => _assets.Remove(tempAsset)) : Task.Run(() => false);
        }

        public Task<Asset> UpdateAsset(Asset asset, string lang)
        {
            int index = _assets.FindIndex(i => i.Id.Equals(asset.Id));
            _assets[index] = asset;
            return Task.Run(() => _assets[index]);
        }

        public Task<List<Common.Models.Type>> GetTypes(bool getNumberOfAssets, string lang)
        {
            if (!getNumberOfAssets)
                return Task.Run(() => _types);

            foreach (var type in _types)
            {
                type.AssetCount += (from Asset asset in _assets
                                    where asset.Type.Id == type.Id
                                    select asset).Count();
            }
            return Task.Run(() => _types);
        }

        public Task<Brand> GetBrand(string name, string lang)
        {
            throw new NotImplementedException();
        }

        public Task<List<Brand>> GetBrands(bool getNumberOfAssets, int typeId, string lang)
        {
            if (!getNumberOfAssets)
                return Task.Run(() => _brands);

            List<Brand> brands = new List<Brand>();
            foreach (var brand in from Brand brand in _brands
                                  from Asset asset in _assets
                                  where asset.Type.Id == typeId
                                  select brand)
            {
                brand.AssetCount++;
                brands.Add(brand);
            }

            return Task.Run(() => brands);
        }

        public Task<int> GetTotalNumberOfResults(Filter filter)
        {
            int total = 0;
            total += (from Asset asset in _assets
                      where asset.Type.Id == filter.TypeId &&
                      asset.Price > filter.MinPrice && asset.Price < filter.MaxPrice
                      select asset).Count();

            return Task.Run(() => total);
        }

        public Task<List<Specification>> GetSpecificationsOfAsset(int id, string lang)
        {
            return Task.Run(() => _assets.Find(x => x.Id.Equals(id)).Specifications);
        }

        public Task<List<Accessory>> GetAccessoriesOfAsset(int id, string lang)
        {
            return Task.Run(() => _assets.Find(x => x.Id.Equals(id)).Accessories);
        }

        public Task<List<Specification>> GetSpecificationsOfType(int id, string lang)
        {
            return Task.Run(() => _assets.Find(x => x.Type.Id.Equals(id)).Specifications);
        }

        public Task<List<Accessory>> GetAccessoriesOfType(int id, string lang)
        {
            return Task.Run(() => _assets.Find(x => x.Type.Id.Equals(id)).Accessories);
        }

        public Task<Brand> CreateBrand(Brand brand, string lang)
        {
            throw new NotImplementedException();
        }
    }
}
