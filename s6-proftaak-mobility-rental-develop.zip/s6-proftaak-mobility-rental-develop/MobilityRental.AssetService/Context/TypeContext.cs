﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MobilityRental.AssetService.Interfaces;
using MobilityRental.Common.Configuration;
using MobilityRental.Common.Context;
using MobilityRental.Common.Extensions;
using MobilityRental.Common.Interfaces;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Type = MobilityRental.Common.Models.Type;

namespace MobilityRental.AssetService.Context
{
    public class TypeContext : SqlDbContext, ITypeContext
    {
        private TranslationSettings _settings;

        #region Constructors
        public TypeContext(IOptions<SQLSettings> _SqlSettings, ILogger<ISqlDbContext> logger, IOptions<TranslationSettings> transSettings) : base(_SqlSettings,
            logger)
        {
            _settings = transSettings.Value;
        }
        #endregion

        #region Methods
        public async Task<Type> GetType(int id, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@Id", id);
            var data = await GetDataAsync("GetTypeOnId", cmd);
            var result = await data.Tables[0].Rows[0].ToType(lang, _settings);
            return result;
        }

        public async Task<Type> GetType(string name, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@Name", name);
            var data = await GetDataAsync("GetTypeOnName", cmd);
            var result = await data.Tables[0].Rows[0].ToType(lang, _settings);
            return result;
        }

        public async Task<Type> CreateType(Type type, string lang)
        {
            SqlCommand command = new SqlCommand();
            command.Parameters.AddWithValue("@Name", type.Name);
            command.Parameters.AddWithValue("@PhotoURL", type.PhotoUrl);
            var ds = await GetDataAsync("CreateType", command);
            var result = new Type();
            if (ds.HasData())
            {
                result = await ds.Tables[0].Rows[0].ToType(lang, _settings);
            }
            return result;
        }

        public async Task<Type> UpdateType(Type type, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@Name", type.Name);
            cmd.Parameters.AddWithValue("@PhotoURL", type.PhotoUrl);
            var ds = await GetDataAsync("UpdateType", cmd);
            var result = new Type();
            if (ds.HasData())
            {
                result = await ds.Tables[0].Rows[0].ToType(lang, _settings);
            }
            return result;
        }

        public async Task<bool> DeleteType(int id)
        {
            SqlCommand command = new SqlCommand
            {
                CommandText = "DeleteType"
            };
            command.Parameters.AddWithValue("@Id", id);
            return ExecuteNonQuery(command) > 0;
        }
    }
    #endregion
}
