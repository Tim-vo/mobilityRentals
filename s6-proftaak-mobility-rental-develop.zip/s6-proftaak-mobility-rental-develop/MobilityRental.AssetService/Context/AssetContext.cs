﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MobilityRental.AssetService.Interfaces;
using MobilityRental.Common.Configuration;
using MobilityRental.Common.Context;
using MobilityRental.Common.Extensions;
using MobilityRental.Common.Interfaces;
using MobilityRental.Common.Models;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace MobilityRental.AssetService.Context
{
    public class AssetContext : SqlDbContext, IAssetContext
    {
        private TranslationSettings settings;

        #region Constructors
        public AssetContext(IOptions<SQLSettings> _SqlSettings, ILogger<ISqlDbContext> logger, IOptions<TranslationSettings> transSettings) : base(_SqlSettings, logger)
        {
            settings = transSettings.Value;
        }
        #endregion

        #region Methods
        public async Task<Asset> GetAsset(int id, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@Id", id);
            var data = await GetDataAsync("GetAssetOnId", cmd);
            var result = await data.Tables[0].Rows[0].ToAsset(lang, settings);
            return result;
        }

        public async Task<List<Asset>> GetPage(Filter filter, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@PageNumber", filter.PageNumber);
            cmd.Parameters.AddWithValue("@AmountPerPage", filter.Amount);
            cmd.Parameters.AddWithValue("@TypeId", filter.TypeId);
            cmd.Parameters.AddWithValue("@Brands", filter.Brands);
            cmd.Parameters.AddWithValue("@MinPrice", filter.MinPrice);
            cmd.Parameters.AddWithValue("@MaxPrice", filter.MaxPrice);
            cmd.Parameters.AddWithValue("@PriceAscending", filter.PriceAscending);

            var data = await GetDataAsync("GetPage", cmd);

            var assets = await data.Tables[0].ToAssetList(lang, settings);

            return assets;
        }

        public async Task<List<Asset>> SearchAssets(string term, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@SearchTerm", term);
            var data = await GetDataAsync("SearchAssets", cmd);
            var result = await data.Tables[0].ToAssetList(lang, settings);
            return result;
        }

        public async Task<Asset> CreateAsset(Asset asset, string lang)
        {
            SqlCommand command = new SqlCommand();
            command.Parameters.AddWithValue("@Name", asset.Name);
            command.Parameters.AddWithValue("@Description", asset.Description);
            command.Parameters.AddWithValue("@PhotoUrl", asset.PhotoUrl);
            command.Parameters.AddWithValue("@Price", asset.Price);
            command.Parameters.AddWithValue("@SerialNumber", asset.SerialNumber);
            command.Parameters.AddWithValue("@TypeId", asset.Type.Id);
            command.Parameters.AddWithValue("@Available", asset.Available);
            command.Parameters.AddWithValue("BrandId", asset.Brand.Id);
            if (asset.PartnerId != null && !asset.PartnerId.Equals(System.Guid.Empty) && asset.PartnerId.ToString().Length > 0)
            {
                command.Parameters.AddWithValue("@PartnerId", asset.PartnerId);
                command.Parameters.AddWithValue("@PartnerAssetId", asset.PartnerAssetId);
                command.Parameters.AddWithValue("@PartnerAssetReferralLink", asset.PartnerReferralLink);
            }

            var ds = await GetDataAsync("CreateAsset", command);
            var result = new Asset();
            if (ds.HasData())
            {
                result = await ds.Tables[0].Rows[0].ToAsset(lang, settings);
            }

            return result;
        }

        public async Task<bool> DeleteAsset(Asset asset)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "DeleteAsset";
            cmd.Parameters.AddWithValue("@Id", asset.Id);
            if (asset.PartnerId != null && !asset.PartnerId.Equals(System.Guid.Empty) && asset.PartnerId.ToString().Length > 0)
            {
                cmd.Parameters.AddWithValue("@PartnerId", asset.PartnerId);
                cmd.Parameters.AddWithValue("@PartnerAssetId", asset.PartnerAssetId);
            }

            return ExecuteNonQuery(cmd) > 0;
        }

        public async Task<Asset> UpdateAsset(Asset asset, string lang)
        {
            SqlCommand command = new SqlCommand();
            command.Parameters.AddWithValue("@Id", asset.Id);
            command.Parameters.AddWithValue("@Name", asset.Name);
            command.Parameters.AddWithValue("@Description", asset.Description);
            command.Parameters.AddWithValue("@PhotoUrl", asset.PhotoUrl);
            command.Parameters.AddWithValue("@Price", asset.Price);
            command.Parameters.AddWithValue("@SerialNumber", asset.SerialNumber);
            command.Parameters.AddWithValue("@TypeId", asset.Type.Id);
            command.Parameters.AddWithValue("@Available", asset.Available);
            command.Parameters.AddWithValue("BrandId", asset.Brand.Id);
            if (asset.PartnerId != null && !asset.PartnerId.Equals(System.Guid.Empty) && asset.PartnerId.ToString().Length > 0)
            {
                command.Parameters.AddWithValue("@PartnerId", asset.PartnerId);
                command.Parameters.AddWithValue("@PartnerAssetId", asset.PartnerAssetId);
                command.Parameters.AddWithValue("@PartnerAssetReferralLink", asset.PartnerReferralLink);
            }

            var ds = await GetDataAsync("UpdateAsset", command);
            var result = new Asset();
            if (ds.HasData())
            {
                result = await ds.Tables[0].Rows[0].ToAsset(lang, settings);
            }

            return result;
        }

        public async Task<List<Type>> GetTypes(bool getNumberOfAssets, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@GetNumberOfAssets", getNumberOfAssets);
            var data = await GetDataAsync("GetTypes", cmd);
            var result = await data.Tables[0].ToTypeList(lang, settings);
            return result;
        }

        public async Task<Brand> CreateBrand(Brand brand, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@Name", brand.Name);
            var data = await GetDataAsync("CreateBrand", cmd);
            var result = await data.Tables[0].Rows[0].ToBrand(lang, settings);
            return result;
        }

        public async Task<Brand> GetBrand(string name, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@Name", name);
            var data = await GetDataAsync("GetBrandByName", cmd);
            if (data.Tables[0].Rows.Count > 0)
            {
                var result = await data.Tables[0].Rows[0].ToBrand(lang, settings);
                return result;
            }
            else
                return null;
        }

        public async Task<List<Brand>> GetBrands(bool getNumberOfAssets, int typeId, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@GetNumberOfAssets", getNumberOfAssets);
            cmd.Parameters.AddWithValue("@TypeId", typeId);
            var data = await GetDataAsync("GetBrands", cmd);
            var result = await data.Tables[0].ToBrandsList(lang, settings);
            return result;
        }

        public async Task<int> GetTotalNumberOfResults(Filter filter)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@TypeId", filter.TypeId);
            cmd.Parameters.AddWithValue("@Brands", filter.Brands);
            cmd.Parameters.AddWithValue("@MinPrice", filter.MinPrice);
            cmd.Parameters.AddWithValue("@MaxPrice", filter.MaxPrice);
            cmd.Parameters.AddWithValue("@PriceAscending", filter.PriceAscending);
            var data = await GetDataAsync("GetTotalNumberOfResults", cmd);
            int result = (int)data.Tables[0].Rows[0].GetValue("TotalNumberOfResults");
            return result;
        }

        public async Task<List<Specification>> GetSpecificationsOfAsset(int id, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@AssetId", id);
            var data = await GetDataAsync("GetSpecificationsOfAsset", cmd);
            var result = await data.Tables[0].ToSpecificationsList(lang, settings);
            return result;
        }

        public async Task<List<Accessory>> GetAccessoriesOfAsset(int id, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@AssetId", id);
            var data = await GetDataAsync("GetAccessoriesOfAsset", cmd);
            var result = await data.Tables[0].ToAccessoriesList(lang, settings);
            return result;
        }

        public async Task<List<Specification>> GetSpecificationsOfType(int typeId, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@TypeId", typeId);
            var data = await GetDataAsync("GetSpecificationsOfType", cmd);
            var result = await data.Tables[0].ToSpecificationsList(lang, settings);
            return result;
        }

        public async Task<List<Accessory>> GetAccessoriesOfType(int typeId, string lang)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@TypeId", typeId);
            var data = await GetDataAsync("GetAccessoriesOfAsset", cmd);
            var result = await data.Tables[0].ToAccessoriesList(lang, settings);
            return result;
        }
        #endregion
    }
}
