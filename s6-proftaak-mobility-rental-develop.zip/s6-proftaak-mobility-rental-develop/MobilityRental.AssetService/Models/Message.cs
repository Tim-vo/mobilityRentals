﻿using MobilityRental.Common.Enums;
using MobilityRental.Common.Models;

namespace MobilityRental.AssetService.Messaging
{
    public class Message
    {
        public AssetActionType AssetActionType { get; set; }
        public Asset Asset { get; set; }

        public Message() { }
        public Message(AssetActionType assetActionType, Asset asset)
        {
            AssetActionType = assetActionType;
            Asset = asset;
        }
    }
}
