using Microsoft.VisualStudio.TestTools.UnitTesting;
using MobilityRental.AssetService.Context.TestContext;
using MobilityRental.AssetService.Controllers;
using MobilityRental.AssetService.Interfaces;
using MobilityRental.Common.Models;
using System.Threading.Tasks;

namespace MobilityRental.AssetServiceTests
{
    [TestClass]
    public class AssetControllerTests
    {
        #region Fields
        private AssetController _controller;
        private readonly IAssetContext _context = new AssetTestContext();
        #endregion

        #region Setup
        [TestInitialize]
        public void Init()
        {
            _controller = new AssetController(_context, null);
        }
        #endregion

        #region Methods

        [TestMethod]
        public async Task TestGetAsset()
        {
            var asset = await this._controller.GetAssetAsync(1);
            Assert.AreEqual("Peugeot 307", asset.Name);
        }

        [TestMethod]
        public async Task TestGetPage()
        {
            var assets = await this._controller.GetPage(new Filter() { PageNumber = 1, Amount = 2, TypeId = 1 });
            Assert.AreEqual(2, assets.Count);
        }

        [TestMethod]
        public async Task TestSearchAssets()
        {
            var assets = await this._controller.SearchAssets("Peugeot");
            Assert.IsNotNull(assets);
        }

        [TestMethod]
        public async Task TestCreateAsset()
        {
            var asset = new Asset()
            {
                Name = "Ford Fiesta",
                Description = "It's a ford!",
                PhotoUrl = "test",
                Price = 334,
                SerialNumber = "S22345",
                Type = new Type() { Id = 1, Name = "Passenger Vehicle", PhotoUrl = "test" },
                Available = true
            };

            var createdAsset = await _controller.CreateAsset(asset);
            Assert.AreEqual(asset.Name, createdAsset.Name);
        }

        [TestMethod]
        public async Task TestDeleteAsset()
        {
            var asset = new Asset()
            {
                Id = 1,
                Name = "Peugeot 307",
                Description = "A nice car",
                PhotoUrl = "test",
                Price = 234,
                SerialNumber = "S12345",
                Type = new Type() { Id = 1, Name = "Passenger Vehicle", PhotoUrl = "test" },
                Available = true
            };

            Assert.IsTrue(await _controller.DeleteAsset(asset));
            Assert.IsFalse(await _controller.DeleteAsset(asset));
        }

        [TestMethod]
        public async Task TestUpdateAsset()
        {
            var asset = new Asset()
            {
                Id = 1,
                Name = "Peugeot 307",
                Description = "It's a Peugeot",
                PhotoUrl = "test",
                Price = 234,
                SerialNumber = "S12345",
                Type = new Type() { Id = 1, Name = "Passenger Vehicle", PhotoUrl = "test" },
                Available = true
            };

            Assert.AreEqual(asset, await _controller.UpdateAsset(asset));
        }

        [TestMethod]
        public void TestGetTypes()
        {
            Assert.IsFalse(_controller.GetTypes(false).Result[0].AssetCount > 0);
            Assert.IsTrue(_controller.GetTypes(true).Result[0].AssetCount > 0);
        }

        [TestMethod]
        public void TestGetBrands()
        {
            Assert.IsFalse(_controller.GetBrands(false, 1).Result[0].AssetCount > 0);
            Assert.IsTrue(_controller.GetBrands(true, 1).Result[0].AssetCount > 0);
        }

        [TestMethod]
        public async Task TestGetAccessoriesAsset()
        {
            Assert.IsNotNull(await _controller.GetAccessoriesOfAsset(1));
        }

        [TestMethod]
        public async Task TestGetAccessoriesType()
        {
            Assert.IsNotNull(await _controller.GetAccessoriesOfType(1));
        }

        [TestMethod]
        public async Task TestGetSpecificationsAsset()
        {
            Assert.IsNotNull(await _controller.GetSpecificationsOfAsset(1));
        }

        [TestMethod]
        public async Task TestGetSpecificationsType()
        {
            Assert.IsNotNull(await _controller.GetSpecificationsOfType(1));
        }

        [TestMethod]
        public async Task TestGetTotalNumberOfResults()
        {
            Assert.AreEqual(1, await _controller.GetTotalNumberOfResults(new Filter() { TypeId = 1, MinPrice = 0, MaxPrice = 300 }));
            Assert.AreEqual(2, await _controller.GetTotalNumberOfResults(new Filter() { TypeId = 1, MinPrice = 0, MaxPrice = 400 }));
        }
        #endregion
    }
}

