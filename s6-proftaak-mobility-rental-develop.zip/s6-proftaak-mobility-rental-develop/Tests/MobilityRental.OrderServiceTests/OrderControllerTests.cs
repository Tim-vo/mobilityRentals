using Microsoft.VisualStudio.TestTools.UnitTesting;
using MobilityRental.Common.Enums;
using MobilityRental.Common.Models;
using MobilityRental.OrderService.Context.TestContext;
using MobilityRental.OrderService.Controllers;
using MobilityRental.OrderService.Interfaces;
using MobilityRental.OrderService.Model;
using System;
using System.Threading.Tasks;

namespace MobilityRental.OrderServiceTests
{
    [TestClass]
    public class OrderUnitTest
    {
        #region Fields
        private OrderController _controller;
        private readonly IOrderContext _context = new OrderTestContext();
        #endregion

        #region Setup
        [TestInitialize]
        public void Init()
        {
            _controller = new OrderController(_context, null, null, null);
        }
        #endregion

        #region Methods
        [TestMethod]
        public async Task CreateOrderTest()
        {
            var order = new Order()
            {
                AccountId = "aaa",
                AssetId = 1,
                StartDate = new DateTime(2020, 08, 05),
                EndDate = new DateTime(2024, 08, 05),
                State = OrderState.PendingOrder,
                Deliver = true
            };

            var asset = new Asset()
            {
                Id = 1,
                Name = "Cool Car",
            };

            var orderAsset = new OrderAsset()
            {
                GetOrder = order,
                GetAsset = asset
            };

            var actualOrder = await _controller.AddOrder(orderAsset);

            Assert.IsInstanceOfType(actualOrder.Id, actualOrder.Id.GetType());
            Assert.IsFalse(string.IsNullOrEmpty(actualOrder.Id));
            Assert.IsNotNull(actualOrder.OrderDate);
            Assert.AreEqual(DateTime.Now.ToString("M"), actualOrder.OrderDate.ToString("M"));
        }
        #endregion
    }
}