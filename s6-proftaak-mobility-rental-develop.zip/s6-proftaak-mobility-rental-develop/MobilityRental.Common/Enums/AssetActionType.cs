﻿namespace MobilityRental.Common.Enums
{
    public enum AssetActionType
    {
        Create,
        Update,
        Delete
    }
}
