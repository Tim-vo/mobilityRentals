﻿namespace MobilityRental.Common.Enums
{
    public enum OrderState
    {
        ReceivedOrder = 0,
        PendingOrder = 1,
        ReadyForPickUp = 2,
        Delivered = 3
    }
}
