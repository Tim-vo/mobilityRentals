﻿namespace MobilityRental.Common.Enums
{
    public enum AccountMethod
    {
        GETALLUSERSONROLE
    }
}
