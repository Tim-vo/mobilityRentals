﻿using MobilityRental.Common.Configuration;
using MobilityRental.Common.Models;
using MobilityRental.Common.Translation;
using System;
using System.Data;
using System.Threading.Tasks;

namespace MobilityRental.Common.Extensions
{
    public static class DataRowExtension
    {

        public static object GetValue(this DataRow row, string column)
        {
            return row.Table.Columns.Contains(column) ? row[column] : null;
        }

        public static int ToInt(this DataRow reader)
        {
            return Convert.ToInt32(reader.ItemArray[0]);
        }


        public static async Task<Asset> ToAsset(this DataRow reader, string language, TranslationSettings settings)
        {
            TranslationService call = new TranslationService(settings);

            int id = Convert.ToInt32(reader["Id"]);
            string name = reader["Name"].ToString();
            string description = reader["Description"].ToString();
            string photoUrl = reader["PhotoUrl"].ToString();
            double price = Convert.ToDouble(reader["Price"]);
            string serialNumber = reader["SerialNumber"].ToString();
            int typeId = Convert.ToInt32(reader["TypeId"]);
            string typeName = reader["TypeName"].ToString();
            string typePhotoUrl = reader["PhotoUrl"].ToString();
            int brandId = Convert.ToInt32(reader["BrandId"]);
            string brandName = reader["BrandName"].ToString();
            bool avail = Convert.ToBoolean(reader["Available"]);
            int partnerAssetId = 0;
            string partnerAssetReferralLink = "";

            if (reader.Table.Columns.Contains("PartnerAssetId") && reader["PartnerAssetId"] != DBNull.Value)
            {
                partnerAssetId = Convert.ToInt32(reader["PartnerAssetId"]);
                partnerAssetReferralLink = reader["PartnerAssetReferralLink"].ToString();
            }

            Asset asset = new Asset()
            {
                Id = id,
                Name = name,
                Description = description,
                PhotoUrl = photoUrl,
                Price = price,
                SerialNumber = serialNumber,
                Type = new Models.Type(typeId, typeName, typePhotoUrl),
                Brand = new Brand(brandId, brandName),
                Available = avail,
                PartnerAssetId = partnerAssetId,
                PartnerReferralLink = partnerAssetReferralLink
            };

            //return await call.GetTranslation(asset, language);
            return asset;
        }

        public async static Task<PersonalInformation> ToPersonalInformation(this DataRow reader, string language, TranslationSettings settings)
        {
            TranslationService call = new TranslationService(settings);

            string name = Convert.ToString(reader["Name"]);
            string email = Convert.ToString(reader["Email"]);
            string city = Convert.ToString(reader["City"]);
            string address = Convert.ToString(reader["Address"]);
            string zipcode = Convert.ToString(reader["Zipcode"]);

            PersonalInformation info = new PersonalInformation()
            {
                Name = name,
                Email = email,
                City = city,
                Address = address,
                Zipcode = zipcode
            };
            return await call.GetTranslation(info, language);
        }

        public static async Task<Models.Type> ToType(this DataRow reader, string language, TranslationSettings settings)
        {
            TranslationService call = new TranslationService(settings);

            int id = Convert.ToInt32(reader["Id"]);
            string name = reader["Name"].ToString();
            string photoUrl = reader["PhotoUrl"].ToString();
            int? assetCount = (int?)reader.GetValue("AssetCount");

            Models.Type type = new Models.Type
            {
                Id = id,
                Name = name,
                PhotoUrl = photoUrl,
                AssetCount = assetCount
            };

            return await call.GetTranslation(type, language);
        }

        public static async Task<Brand> ToBrand(this DataRow reader, string language, TranslationSettings settings)
        {
            TranslationService call = new TranslationService(settings);

            int id = Convert.ToInt32(reader["Id"]);
            string name = reader["Name"].ToString();
            int? assetCount = (int?)reader.GetValue("AssetCount");

            Brand brand = new Brand
            {
                Id = id,
                Name = name,
                AssetCount = assetCount
            };

            return await call.GetTranslation(brand, language); ;
        }

        public static async Task<Specification> ToSpecification(this DataRow reader, string language, TranslationSettings settings)
        {
            TranslationService call = new TranslationService(settings);

            string name = reader["Name"].ToString();
            string value = reader["Value"].ToString();

            Specification specification = new Specification()
            {
                Name = name,
                Value = value
            };

            return await call.GetTranslation(specification, language); ;
        }

        public static async Task<Accessory> ToAccessory(this DataRow reader, string language, TranslationSettings settings)
        {
            TranslationService call = new TranslationService(settings);

            int id = -1;
            string name = string.Empty;

            if (reader.Table.Columns.Contains("AccessoryId"))
                id = Convert.ToInt32(reader["AccessoryId"]);
            else if (reader.Table.Columns.Contains("Id"))
                id = Convert.ToInt32(reader["Id"]);

            if (reader.Table.Columns.Contains("Name"))
                name = reader["Name"].ToString();

            Accessory accessory = new Accessory()
            {
                Id = id,
                Name = name
            };

            return await call.GetTranslation(accessory, language); ;
        }
    }
}