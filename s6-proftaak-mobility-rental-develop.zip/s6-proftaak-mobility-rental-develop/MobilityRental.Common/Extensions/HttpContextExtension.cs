﻿using Microsoft.AspNetCore.Http;

namespace MobilityRental.Common.Extensions
{
    public static class HttpContextExtension
    {
        public static string GetLanguage(this HttpContext httpContext)
        {
            return httpContext.Request.GetTypedHeaders().AcceptLanguage[0].ToString().Split("-")[0];
        }
    }
}
