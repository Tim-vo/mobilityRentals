﻿using MobilityRental.Common.Configuration;
using MobilityRental.Common.Models;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace MobilityRental.Common.Extensions
{
    public static class DataTableExtension
    {
        public static async Task<List<Asset>> ToAssetList(this DataTable table, string language, TranslationSettings settings)
        {
            List<Asset> result = new List<Asset>();

            foreach (DataRow row in table.Rows)
            {
                if (!row.HasErrors)
                {
                    result.Add(await row.ToAsset(language, settings));
                }
            }

            return result;
        }

        public static async Task<List<Type>> ToTypeList(this DataTable table, string language, TranslationSettings settings)
        {
            List<Type> result = new List<Type>();

            foreach (DataRow row in table.Rows)
            {
                if (!row.HasErrors)
                {
                    result.Add(await row.ToType(language, settings));
                }
            }

            return result;
        }

        public static async Task<List<Brand>> ToBrandsList(this DataTable table, string language, TranslationSettings settings)
        {
            List<Brand> result = new List<Brand>();

            foreach (DataRow row in table.Rows)
            {
                if (!row.HasErrors)
                {
                    result.Add(await row.ToBrand(language, settings));
                }
            }

            return result;
        }

        public static async Task<List<Specification>> ToSpecificationsList(this DataTable table, string language, TranslationSettings settings)
        {
            List<Specification> result = new List<Specification>();

            foreach (DataRow row in table.Rows)
            {
                if (!row.HasErrors)
                {
                    result.Add(await row.ToSpecification(language, settings));
                }
            }

            return result;
        }

        public static async Task<List<Accessory>> ToAccessoriesList(this DataTable table, string language, TranslationSettings settings)
        {
            List<Accessory> result = new List<Accessory>();

            foreach (DataRow row in table.Rows)
            {
                if (!row.HasErrors)
                {
                    result.Add(await row.ToAccessory(language, settings));
                }
            }

            return result;
        }
    }
}
