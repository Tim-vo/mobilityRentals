﻿namespace MobilityRental.Common.Interfaces
{
    public interface ISqlDbContext
    {
    }
}
