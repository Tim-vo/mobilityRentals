﻿namespace MobilityRental.Common.Configuration
{
    public class TranslationSettings
    {
        public string Subscription { get; set; }

    }
}
