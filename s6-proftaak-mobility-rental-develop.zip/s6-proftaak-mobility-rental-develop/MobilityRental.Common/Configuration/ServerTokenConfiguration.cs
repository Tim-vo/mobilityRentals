﻿namespace MobilityRental.Common.Configuration
{
    public class ServerTokenConfiguration
    {
        public string Jwt { get; set; }
        public string GatewayUrl { get; set; }
    }
}
