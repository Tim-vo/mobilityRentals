﻿namespace MobilityRental.Common.Configuration
{
    public class MessageSettings
    {
        public string HostName { get; set; }
        public string Channel { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
