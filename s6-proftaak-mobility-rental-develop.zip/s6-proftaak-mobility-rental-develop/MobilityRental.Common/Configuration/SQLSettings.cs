﻿namespace MobilityRental.Common.Configuration
{
    public class SQLSettings
    {
        public string ConnectionString { get; set; }
    }
}
