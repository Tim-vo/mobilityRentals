﻿using Microsoft.Extensions.Options;
using MobilityRental.Common.Configuration;
using Namotion.Reflection;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace MobilityRental.Common.Translation
{
    public class TranslationService
    {
        #region FIELDS
        private string subscriptionKey;
        private static readonly string endpoint = "https://api.cognitive.microsofttranslator.com";
        private string route = "/translate?api-version=3.0&to=";


        private static Dictionary<string, object> _cacheList = new Dictionary<string, object>();

        #endregion

        #region SETUP
        public TranslationService(TranslationSettings _settings)
        {
            subscriptionKey = _settings.Subscription;
            if (null == subscriptionKey)
            {
                throw new Exception("Please set/export the environment variable: " + subscriptionKey);
            }
            if (null == endpoint)
            {
                throw new Exception("Please set/export the environment variable: " + endpoint);
            }
        }

        public TranslationService(IOptions<TranslationSettings> _settings)
        {
            subscriptionKey = _settings.Value.Subscription;
            if (null == subscriptionKey)
            {
                throw new Exception("Please set/export the environment variable: " + subscriptionKey);
            }
            if (null == endpoint)
            {
                throw new Exception("Please set/export the environment variable: " + endpoint);
            }
        }
        #endregion

        #region METHODS
        /// <summary>
        /// The POST request to the API
        /// </summary>
        /// <param name="body">The Json string</param>
        /// <returns>Json result string</returns>
        private async Task<string> Post(string body, string language)
        {
            using (HttpClient client = new HttpClient())
            using (HttpRequestMessage request = new HttpRequestMessage())
            {
                request.Method = HttpMethod.Post;
                request.RequestUri = new Uri(endpoint + route + language);
                request.Content = new StringContent(body, Encoding.UTF8, "application/json");
                request.Headers.Add("Ocp-Apim-Subscription-Key", subscriptionKey);

                HttpResponseMessage response = await client.SendAsync(request);
                return await response.Content.ReadAsStringAsync();
            }
        }

        /// <summary>
        /// Gets the translation(s) from the serialized object
        /// </summary>
        /// <param name="text">The text that needs to be translated</param>
        /// <returns>List of answers to the question</returns>
        public async Task<T> GetTranslation<T>(T obj, string language)
        {
            T result = default(T);
            bool cacheFound = false;
            if (_cacheList.Count > 0)
            {
                if (obj.HasProperty("Id"))
                {
                    string id = string.Empty;
                    try
                    {
                        id = obj.TryGetPropertyValue("Id", string.Empty);
                    }
                    catch
                    {
                        id = (obj.TryGetPropertyValue("Id", 0)).ToString();
                    }

                    if (!string.IsNullOrEmpty(id) && id != "0")
                    {
                        id = obj.GetType() + id + language; //so we can store with languages
                        if (_cacheList.ContainsKey(id))
                        {
                            result = (T)_cacheList[id];
                            if (result != null)
                            {
                                // Console.WriteLine($"Found {id} in cache");
                                cacheFound = true;
                            }
                        }
                    }

                }
            }

            if (!cacheFound)
            {
                foreach (PropertyInfo property in obj.GetType().GetProperties())
                {
                    if (property.PropertyType == typeof(string))
                    {
                        object[] body = new object[] { new { Text = property.GetValue(obj) } };
                        string requestBody = JsonConvert.SerializeObject(body);
                        if (requestBody.Contains(":null}"))
                            continue;
                        string response = await Post(requestBody, language);

                        TranslationServices[] deserializedOutput =
                            JsonConvert.DeserializeObject<TranslationServices[]>(response);
                        // Iterate over the deserialized results.
                        foreach (TranslationServices o in deserializedOutput)
                        {
                            foreach (Translation t in o.Translations)
                            {
                                property.SetValue(obj, t.Text);
                            }
                        }
                    }
                }

                result = (T)Convert.ChangeType(obj, typeof(T));

                if (obj.HasProperty("Id"))
                {
                    string id = string.Empty;
                    try
                    {
                        id = obj.TryGetPropertyValue("Id", string.Empty);
                    }
                    catch
                    {
                        id = (obj.TryGetPropertyValue("Id", 0)).ToString();
                    }
                    if (!string.IsNullOrEmpty(id) && id != "0")
                    {
                        id = obj.GetType() + id + language;
                        _cacheList.Add(id, result);
                        // Console.WriteLine($"Storing {id}in cache");
                    }
                }
            }

            return result;
        }
        #endregion
    }
}
