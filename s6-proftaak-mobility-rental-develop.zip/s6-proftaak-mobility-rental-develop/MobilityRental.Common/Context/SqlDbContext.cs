﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MobilityRental.Common.Configuration;
using MobilityRental.Common.Interfaces;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace MobilityRental.Common.Context
{
    /// <summary>
    /// Generic class with SQL Methods
    /// </summary>
    public class SqlDbContext : ISqlDbContext
    {
        #region Fields
        private readonly SqlConnection _conn;
        private readonly ILogger<ISqlDbContext> _logger;
        #endregion

        #region Setup
        public SqlDbContext(IOptions<SQLSettings> _SqlSettings, ILogger<ISqlDbContext> logger)
        {
            _logger = logger;
            _conn = new SqlConnection(_SqlSettings.Value.ConnectionString);
        }
        #endregion

        #region Methods
        public ConnectionState GetConnectionState()
        {
            return _conn.State;
        }

        public SqlConnection OpenConnection()
        {
            try
            {
                if (_conn.State == ConnectionState.Closed)
                {
                    _conn.Open();
                    _logger.LogInformation("Opened connection to database");
                }
                else
                {
                    _logger.LogInformation("Already opened connection to database");
                }
            }
            catch (Exception exp)
            {
                _logger.LogInformation("Couldn't connect to database: " + exp);
                throw;
            }
            return _conn;
        }

        public bool CloseConnection()
        {
            bool result = false;
            if (_conn.State == ConnectionState.Open)
            {
                _conn.Close();
                result = true;
            }
            _logger.LogInformation("Closed connection to database");
            return result;
        }


        public async Task<DataSet> GetDataAsync(string procedure, SqlCommand cmd)
        {
            try
            {
                cmd.Connection = OpenConnection();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = procedure;

                DataSet ds = new DataSet();

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);

                CloseConnection();
                return ds;
            }
            catch (Exception error)
            {
                _logger.LogError(error, "Failed GetDataAsync for {cmdname}", procedure);
                throw;
            }
        }

        public int ExecuteNonQuery(SqlCommand cmd)
        {
            try
            {
                cmd.Connection = OpenConnection();
                cmd.CommandType = CommandType.StoredProcedure;
                return cmd.ExecuteNonQuery();
            }
            catch (Exception error)
            {
                _logger.LogError(error, "Failed ExecuteNonQuery for {cmdname}", cmd.CommandText);
                throw;
            }
            finally
            {
                CloseConnection();
            }
        }

        public async Task<SqlDataReader> ExecuteReaderAsync(SqlCommand cmd)
        {
            try
            {
                return await cmd.ExecuteReaderAsync();
            }
            catch (Exception error)
            {
                _logger.LogError(error, "Failed ExecuteReaderAsync for {cmdname}", cmd.CommandText);
                CloseConnection();
                throw;
            }

        }
        #endregion
    }
}
