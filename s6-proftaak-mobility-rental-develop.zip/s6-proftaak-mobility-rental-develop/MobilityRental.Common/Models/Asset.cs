﻿using System;
using System.Collections.Generic;

namespace MobilityRental.Common.Models
{
    public class Asset
    {
        #region Setup
        public Asset() { }
        #endregion

        #region Properties
        public int Id { get; set; }
        public string Name { get; set; }
        public string SerialNumber { get; set; }
        public string PhotoUrl { get; set; }
        public double Price { get; set; }
        public string Description { get; set; }
        public bool Available { get; set; }
        public Brand Brand { get; set; }
        public Type Type { get; set; }
        public List<Specification> Specifications { get; set; }
        public List<Accessory> Accessories { get; set; }
        public Guid PartnerId { get; set; }
        public int PartnerAssetId { get; set; }
        public string PartnerReferralLink { get; set; }
        #endregion
    }
}
