﻿using MobilityRental.Common.Enums;

namespace MobilityRental.Common.Models
{
    public class AccountMessage
    {
        public AccountMethod Method { get; set; }
        /// <summary>
        ///The exchange this this needs to be sent back to
        /// </summary>
        public string Origin { get; set; }
        public object Data { get; set; }
    }
}
