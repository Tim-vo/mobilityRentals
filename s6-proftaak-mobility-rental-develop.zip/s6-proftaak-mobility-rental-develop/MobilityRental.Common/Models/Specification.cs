﻿namespace MobilityRental.Common.Models
{
    public class Specification
    {
        #region Setup
        public Specification() { }
        #endregion

        #region Properties
        public int Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        #endregion
    }
}
