﻿namespace MobilityRental.Common.Models
{
    public class Brand
    {
        #region Setup
        public Brand() { }

        public Brand(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public Brand(int id, string name, int assetCount)
        {
            Id = id;
            Name = name;
            AssetCount = assetCount;
        }
        #endregion

        #region Properties
        public int Id { get; set; }
        public string Name { get; set; }
        public int? AssetCount { get; set; }
        #endregion
    }
}
