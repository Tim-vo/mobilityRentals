﻿namespace MobilityRental.Common.Models
{
    public class Accessory
    {
        #region Setup
        public Accessory() { }
        #endregion 

        #region Properties
        public int Id { get; set; }
        public string Name { get; set; }
        #endregion
    }
}
