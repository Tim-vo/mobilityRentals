﻿namespace MobilityRental.Common.Models
{
    public class Type
    {
        #region Setup
        public Type() { }

        public Type(int id, string name, string photoUrl)
        {
            Id = id;
            Name = name;
            PhotoUrl = photoUrl;
        }

        public Type(int id, string name, string photoUrl, int assetCount)
        {
            Id = id;
            Name = name;
            PhotoUrl = photoUrl;
            AssetCount = assetCount;
        }
        #endregion

        #region Properties
        public int Id { get; set; }
        public string Name { get; set; }
        public string PhotoUrl { get; set; }
        public int? AssetCount { get; set; }
        #endregion
    }
}
