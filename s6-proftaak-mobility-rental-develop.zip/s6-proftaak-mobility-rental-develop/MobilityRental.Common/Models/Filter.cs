﻿namespace MobilityRental.Common.Models
{
    public class Filter
    {
        #region Setup
        public Filter() { }
        #endregion 

        #region Properties
        public int PageNumber { get; set; }
        public int Amount { get; set; }
        public int TypeId { get; set; }
        public string Brands { get; set; }
        public double MinPrice { get; set; }
        public double MaxPrice { get; set; }
        public bool PriceAscending { get; set; }
        #endregion
    }
}
