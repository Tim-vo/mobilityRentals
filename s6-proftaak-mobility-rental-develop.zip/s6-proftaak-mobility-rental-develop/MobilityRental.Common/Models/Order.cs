﻿using MobilityRental.Common.Enums;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MobilityRental.Common.Models
{
    public class Order
    {
        #region Setup
        public Order() { }
        #endregion

        #region Properties
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string Id { get; set; }
        public string AccountId { get; set; }
        public int AssetId { get; set; }
        public string Number { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public OrderState State { get; set; }
        public bool Deliver { get; set; }
        public string Accessories { get; set; }

        public PersonalInformation PersonalInformation { get; set; }
        #endregion
    }
}
